# 🤖 Nexora Chatbot - Sistema de Conversación Empresarial

Chatbot profesional de última generación para **Nexora Analytics & AI**, con integración OpenAI, calificación automática de leads y diseño futurista tipo Silicon Valley.

![Nexora Chatbot](https://img.shields.io/badge/Nexora-Chatbot-00F5FF?style=for-the-badge)
![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4o-412991?style=for-the-badge)
![Node.js](https://img.shields.io/badge/Node.js-18+-339933?style=for-the-badge)

---

## ✨ Características

### 🎯 Funcionalidades Principales
- **Respuestas Inteligentes** con GPT-4o-mini de OpenAI
- **Calificación Automática de Leads** (score 0-100)
- **Captura de Datos** (nombre, empresa, email, industria)
- **Agendamiento de Reuniones** integrado
- **Detección de Intenciones** (servicios, precios, contacto)
- **Funciona 24/7** sin intervención humana

### 🎨 Diseño UI/UX
- **Glassmorphism** con efectos de blur
- **Animaciones Suaves** y transiciones elegantes
- **Indicador de "Escribiendo..."** con dots animados
- **Scroll Automático** en conversación
- **100% Responsive** (desktop y móvil)
- **Colores Nexora** (#0B1120, #00F5FF, #9CA3AF)

### 🔒 Seguridad
- API Key nunca expuesta en frontend
- Rate limiting (100 req/15min por IP)
- Validación de inputs con express-validator
- Sanitización contra XSS
- Headers de seguridad con Helmet
- Logging completo de actividad

---

## 📁 Estructura del Proyecto

```
nexora-chatbot/
├── backend/
│   ├── server.js           # Servidor Express principal
│   ├── package.json        # Dependencias Node.js
│   ├── .env.example        # Variables de entorno de ejemplo
│   └── logs/               # Logs de actividad
├── frontend/
│   ├── index.html          # Página demo
│   └── chatbot.js          # Módulo JavaScript del chatbot
└── README.md               # Este archivo
```

---

## 🚀 Instalación Rápida

### Prerrequisitos
- Node.js 18+ instalado
- Cuenta en OpenAI con API Key

### 1. Clonar y Configurar Backend

```bash
# Entrar al directorio backend
cd backend

# Instalar dependencias
npm install

# Crear archivo de configuración
cp .env.example .env

# Editar .env con tu API Key de OpenAI
# OPENAI_API_KEY=sk-tu-api-key-aqui
```

### 2. Iniciar Servidor

```bash
# Modo desarrollo (con auto-reload)
npm run dev

# Modo producción
npm start
```

El servidor estará corriendo en: `http://localhost:3001`

### 3. Probar Frontend

Abre `frontend/index.html` en tu navegador o usa un servidor local:

```bash
# Opción 1: Python
python -m http.server 3000

# Opción 2: Node.js
npx serve frontend

# Opción 3: VS Code Live Server
```

---

## 🔌 Integración en tu Sitio Web

### Método 1: Script Directo (Recomendado)

```html
<!-- Agrega esto antes del cierre de </body> -->
<div id="nexora-chatbot"></div>
<script src="https://tu-dominio.com/chatbot.js"></script>
<script>
  // Configuración opcional
  window.NEXORA_CHATBOT_API_URL = 'https://tu-api.com/api/chat';
</script>
```

### Método 2: React/Vue/Angular

```javascript
// Importar el módulo
import './chatbot.js';

// O usar como componente
useEffect(() => {
  const script = document.createElement('script');
  script.src = '/chatbot.js';
  document.body.appendChild(script);
  
  return () => document.body.removeChild(script);
}, []);
```

### Método 3: WordPress

```php
// En tu functions.php o plugin
function add_nexora_chatbot() {
    wp_enqueue_script('nexora-chatbot', 'https://tu-dominio.com/chatbot.js', [], '1.0', true);
    wp_add_inline_script('nexora-chatbot', '
        window.NEXORA_CHATBOT_API_URL = "https://tu-api.com/api/chat";
    ', 'before');
}
add_action('wp_footer', 'add_nexora_chatbot');
```

---

## 🔧 Configuración Avanzada

### Variables de Entorno

| Variable | Descripción | Default |
|----------|-------------|---------|
| `PORT` | Puerto del servidor | 3001 |
| `OPENAI_API_KEY` | Tu API Key de OpenAI | - |
| `OPENAI_MODEL` | Modelo GPT a usar | gpt-4o-mini |
| `FRONTEND_URL` | URL permitida para CORS | * |
| `LOG_LEVEL` | Nivel de logging | info |

### Personalizar el Prompt del Sistema

Edita `SYSTEM_PROMPT` en `backend/server.js` para cambiar la personalidad del bot:

```javascript
const SYSTEM_PROMPT = `Eres el Asistente de [Tu Empresa]...

🎯 TU MISIÓN:
- [Define tu objetivo]

📋 SERVICIOS:
1. [Servicio 1]
2. [Servicio 2]

🗣️ TONO:
- [Define el tono de voz]
`;
```

### Personalizar Colores y Estilo

En `frontend/chatbot.js`, modifica el objeto `CONFIG`:

```javascript
const CONFIG = {
  BOT_NAME: 'Mi Asistente',
  BOT_AVATAR: '🤖',
  COLORS: {
    primary: '#00F5FF',
    midnight: '#0B1120',
    // ...
  },
  WELCOME_MESSAGE: '¡Hola! Bienvenido...',
  QUICK_SUGGESTIONS: [
    '¿Qué servicios ofrecen?',
    // ...
  ],
};
```

---

## 📊 API Endpoints

### POST `/api/chat`
Envía un mensaje al chatbot.

**Request:**
```json
{
  "message": "¿Qué servicios ofrecen?",
  "sessionId": "uuid-de-sesion"
}
```

**Response:**
```json
{
  "success": true,
  "response": "Ofrecemos análisis de datos, IA y consultoría predictiva...",
  "sessionId": "uuid-de-sesion",
  "intent": "servicios",
  "leadInfo": {
    "nombre": "Juan",
    "empresa": "TechCorp"
  },
  "leadScore": 65,
  "isLeadQualified": true,
  "metadata": {
    "responseTimeMs": 1200,
    "tokensUsed": 150,
    "model": "gpt-4o-mini"
  }
}
```

### POST `/api/schedule`
Agenda una reunión.

**Request:**
```json
{
  "sessionId": "uuid-de-sesion",
  "date": "2026-02-20T10:00:00Z",
  "email": "juan@techcorp.com",
  "nombre": "Juan Pérez"
}
```

### GET `/api/health`
Health check del servidor.

### GET `/api/leads`
Lista todos los leads capturados (proteger en producción).

---

## 📈 Escalabilidad

### Base de Datos (Recomendado para Producción)

Reemplaza el almacenamiento en memoria con PostgreSQL:

```javascript
// Instalar: npm install pg
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Guardar conversación
await pool.query(
  'INSERT INTO conversations (session_id, messages, lead_info) VALUES ($1, $2, $3)',
  [sessionId, JSON.stringify(messages), JSON.stringify(leadInfo)]
);
```

### Redis para Sesiones

```bash
npm install redis
```

```javascript
const redis = require('redis');
const client = redis.createClient({ url: process.env.REDIS_URL });

// Guardar sesión
await client.setEx(`session:${sessionId}`, 3600, JSON.stringify(conversation));
```

### Docker para Deployment

```dockerfile
# Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3001
CMD ["npm", "start"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  chatbot:
    build: ./backend
    ports:
      - "3001:3001"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - DATABASE_URL=${DATABASE_URL}
    volumes:
      - ./logs:/app/logs
```

### Load Balancing con Nginx

```nginx
upstream chatbot_backend {
    server 127.0.0.1:3001;
    server 127.0.0.1:3002;
    server 127.0.0.1:3003;
}

server {
    listen 80;
    location /api/ {
        proxy_pass http://chatbot_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
    }
}
```

---

## 🔮 Roadmap y Mejoras Futuras

### Próximas Features
- [ ] **WebSockets** para respuestas en tiempo real
- [ ] **Análisis de Sentimiento** para priorizar leads
- [ ] **Multi-idioma** (español, inglés, portugués)
- [ ] **Integración WhatsApp Business**
- [ ] **Dashboard Admin** para ver conversaciones
- [ ] **Notificaciones Email** para leads calificados
- [ ] **A/B Testing** de mensajes de bienvenida
- [ ] **Machine Learning** para mejorar respuestas

### Integraciones
- [ ] **Calendly** para agendamiento nativo
- [ ] **HubSpot/Salesforce** para CRM
- [ ] **Slack** para notificaciones al equipo
- [ ] **Zapier** para automatizaciones

---

## 🐛 Troubleshooting

### Error: "API Key no válida"
```bash
# Verificar que la API Key esté configurada
cat backend/.env | grep OPENAI_API_KEY

# Probar la API Key
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer sk-tu-api-key"
```

### Error: "CORS blocked"
```bash
# Verificar FRONTEND_URL en .env
FRONTEND_URL=https://tu-dominio.com
```

### Error: "Rate limit exceeded"
- El rate limiting está configurado a 100 requests por 15 minutos
- Ajustar en `server.js` si es necesario

---

## 📄 Licencia

MIT License - Nexora Analytics & AI

---

## 💬 Soporte

¿Necesitas ayuda? Contáctanos:
- 📧 Email: hola@nexora.ai
- 💬 WhatsApp: +52 55 1234 5678
- 🌐 Web: https://nexora.ai

---

<p align="center">
  <strong>Desarrollado con 💙 por Nexora Analytics & AI</strong>
</p>
