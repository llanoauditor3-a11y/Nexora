/**
 * ==========================================
 * NEXORA CHATBOT - COMPONENTE REACT
 * ==========================================
 * 
 * Componente React para integración en aplicaciones Next.js/React
 * con TypeScript y hooks modernos.
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User, 
  Minimize2, 
  Calendar,
  CheckCircle,
  Sparkles
} from 'lucide-react';

// ==========================================
// TIPOS
// ==========================================
interface Message {
  id: number;
  type: 'user' | 'bot';
  text: string;
  timestamp: Date;
  metadata?: {
    leadScore?: number;
    isLeadQualified?: boolean;
  };
}

interface LeadInfo {
  nombre?: string;
  email?: string;
  empresa?: string;
  industria?: string;
  tamaño?: string;
  necesidad?: string;
}

interface ChatResponse {
  success: boolean;
  response: string;
  sessionId: string;
  intent: string;
  leadInfo: LeadInfo;
  leadScore: number;
  isLeadQualified: boolean;
  metadata: {
    responseTimeMs: number;
    tokensUsed: number;
    model: string;
  };
}

// ==========================================
// CONFIGURACIÓN
// ==========================================
const CONFIG = {
  API_URL: process.env.NEXT_PUBLIC_CHATBOT_API_URL || 'http://localhost:3001/api/chat',
  SCHEDULE_URL: process.env.NEXT_PUBLIC_CHATBOT_API_URL?.replace('/chat', '/schedule') || 'http://localhost:3001/api/schedule',
  WELCOME_MESSAGE: '¡Hola! Soy el asistente virtual de Nexora Analytics & AI. ¿En qué puedo ayudarte hoy?',
  QUICK_SUGGESTIONS: [
    '¿Qué servicios ofrecen?',
    'Quiero una demo',
    '¿Cuáles son los precios?',
    'Agendar reunión'
  ],
  TYPING_DELAY: 1000,
};

// ==========================================
// UTILIDADES
// ==========================================
const generateSessionId = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

const formatTime = (date: Date): string => {
  return date.toLocaleTimeString('es-ES', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
};

// ==========================================
// COMPONENTE PRINCIPAL
// ==========================================
export const NexoraChatbot: React.FC = () => {
  // Estado
  const [isOpen, setIsOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [sessionId, setSessionId] = useState<string>('');
  const [leadInfo, setLeadInfo] = useState<LeadInfo>({});
  const [leadScore, setLeadScore] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [meetingScheduled, setMeetingScheduled] = useState(false);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // ==========================================
  // EFECTOS
  // ==========================================
  
  // Inicializar sesión
  useEffect(() => {
    const saved = localStorage.getItem('nexora_chatbot_state');
    if (saved) {
      const parsed = JSON.parse(saved);
      setSessionId(parsed.sessionId || generateSessionId());
      setMessages(parsed.messages || []);
      setLeadInfo(parsed.leadInfo || {});
      setLeadScore(parsed.leadScore || 0);
    } else {
      setSessionId(generateSessionId());
    }
  }, []);

  // Mensaje de bienvenida
  useEffect(() => {
    if (messages.length === 0 && sessionId) {
      addMessage('bot', CONFIG.WELCOME_MESSAGE);
    }
  }, [sessionId]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Focus en input
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
      setUnreadCount(0);
    }
  }, [isOpen]);

  // Guardar estado
  useEffect(() => {
    if (sessionId) {
      localStorage.setItem('nexora_chatbot_state', JSON.stringify({
        sessionId,
        messages: messages.slice(-10),
        leadInfo,
        leadScore,
      }));
    }
  }, [sessionId, messages, leadInfo, leadScore]);

  // ==========================================
  // FUNCIONES
  // ==========================================

  const addMessage = useCallback((type: 'user' | 'bot', text: string, metadata?: any) => {
    const message: Message = {
      id: Date.now(),
      type,
      text,
      timestamp: new Date(),
      metadata,
    };

    setMessages(prev => [...prev.slice(-49), message]);

    if (type === 'bot' && !isOpen) {
      setUnreadCount(prev => prev + 1);
    }
  }, [isOpen]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || isTyping) return;

    // Agregar mensaje del usuario
    addMessage('user', text);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch(CONFIG.API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, sessionId }),
      });

      if (!response.ok) throw new Error('Error en la respuesta');

      const data: ChatResponse = await response.json();

      // Simular delay natural
      await new Promise(resolve => setTimeout(resolve, CONFIG.TYPING_DELAY));

      setIsTyping(false);
      addMessage('bot', data.response, {
        leadScore: data.leadScore,
        isLeadQualified: data.isLeadQualified,
      });

      // Actualizar lead info
      setLeadInfo(data.leadInfo);
      setLeadScore(data.leadScore);

      // Mostrar opción de agendar si está calificado
      if (data.isLeadQualified && !meetingScheduled) {
        setTimeout(() => setShowScheduleForm(true), 500);
      }

    } catch (error) {
      setIsTyping(false);
      addMessage('bot', 'Lo siento, tuve un problema al procesar tu mensaje. ¿Podrías intentar de nuevo?');
    }
  };

  const handleScheduleMeeting = async (formData: {
    nombre: string;
    email: string;
    empresa: string;
    horario: string;
  }) => {
    try {
      const response = await fetch(CONFIG.SCHEDULE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...formData,
          date: new Date(Date.now() + 86400000).toISOString(),
        }),
      });

      if (response.ok) {
        setMeetingScheduled(true);
        setShowScheduleForm(false);
        addMessage('bot', `¡Excelente ${formData.nombre}! Tu reunión ha sido agendada. Te enviaremos un correo de confirmación a ${formData.email}.`);
        
        setLeadInfo(prev => ({
          ...prev,
          nombre: formData.nombre,
          email: formData.email,
          empresa: formData.empresa,
        }));
      }
    } catch (error) {
      addMessage('bot', 'Lo siento, hubo un problema al agendar la reunión. Por favor intenta más tarde.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputValue);
  };

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <>
      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full
          flex items-center justify-center
          transition-all duration-300
          ${isOpen 
            ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
            : 'bg-gradient-to-r from-[#00F5FF] to-[#00C8D0] text-[#0B1120] hover:shadow-lg hover:shadow-[#00F5FF]/30 animate-pulse'
          }
        `}
        style={{
          boxShadow: isOpen ? 'none' : '0 0 20px rgba(0, 245, 255, 0.4)',
        }}
        aria-label={isOpen ? 'Cerrar chat' : 'Abrir chat'}
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
        
        {/* Unread Badge */}
        {!isOpen && unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-bold">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Chat Window */}
      <div
        className={`
          fixed z-50 overflow-hidden
          transition-all duration-500 origin-bottom-right
          ${isOpen 
            ? 'opacity-100 scale-100 translate-y-0' 
            : 'opacity-0 scale-95 translate-y-4 pointer-events-none'
          }
          ${typeof window !== 'undefined' && window.innerWidth < 768 
            ? 'bottom-0 left-0 right-0 w-full rounded-t-2xl' 
            : 'bottom-24 right-6 w-[400px] max-w-[90vw] rounded-2xl'
          }
        `}
        style={{
          background: 'rgba(15, 23, 42, 0.95)',
          backdropFilter: 'blur(16px)',
          border: '1px solid rgba(0, 245, 255, 0.15)',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#00F5FF]/10 bg-[#0B1120]/50">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-[#00F5FF]/30 rounded-full blur-md animate-pulse" />
              <div className="relative w-10 h-10 rounded-full bg-gradient-to-br from-[#00F5FF]/30 to-[#00F5FF]/10 border border-[#00F5FF]/40 flex items-center justify-center">
                <Bot className="w-5 h-5 text-[#00F5FF]" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-[#0B1120]" />
            </div>
            <div>
              <span className="text-sm font-medium text-white block">Nexora Assistant</span>
              <span className="text-xs text-[#9CA3AF] flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                En línea ahora
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <button 
              onClick={() => setIsOpen(false)}
              className="p-2 text-[#9CA3AF] hover:text-[#00F5FF] hover:bg-[#00F5FF]/10 rounded-lg transition-all"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setIsOpen(false)}
              className="p-2 text-[#9CA3AF] hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messages Area */}
        <div 
          className="h-80 overflow-y-auto p-4 space-y-4"
          style={{ scrollbarWidth: 'thin', scrollbarColor: '#00F5FF #0B1120' }}
        >
          {/* Info Banner */}
          <div className="bg-[#00F5FF]/5 border border-[#00F5FF]/10 rounded-xl p-3">
            <p className="text-xs text-[#9CA3AF] text-center">
              Este asistente puede ayudarte con información sobre nuestros servicios.
            </p>
          </div>

          {/* Messages */}
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-2 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}
            >
              {/* Avatar */}
              <div 
                className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${
                  message.type === 'user' 
                    ? 'bg-[#00F5FF]/20' 
                    : 'bg-[#0B1120] border border-[#00F5FF]/30'
                }`}
              >
                {message.type === 'user' ? (
                  <User className="w-3.5 h-3.5 text-[#00F5FF]" />
                ) : (
                  <Bot className="w-3.5 h-3.5 text-[#00F5FF]" />
                )}
              </div>

              {/* Message Bubble */}
              <div 
                className={`max-w-[75%] px-3 py-2 text-sm ${
                  message.type === 'user'
                    ? 'bg-gradient-to-r from-[#00F5FF]/20 to-[#00F5FF]/5 border border-[#00F5FF]/30 text-white rounded-2xl rounded-tr-sm'
                    : 'bg-[#0B1120]/80 border border-white/10 text-[#D1D5DB] rounded-2xl rounded-tl-sm'
                }`}
              >
                <p className="leading-relaxed">{message.text}</p>
                <span className={`text-[10px] mt-1 block ${message.type === 'user' ? 'text-[#00F5FF]/60' : 'text-[#9CA3AF]/60'}`}>
                  {formatTime(message.timestamp)}
                </span>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex gap-2">
              <div className="flex-shrink-0 w-7 h-7 rounded-full bg-[#0B1120] border border-[#00F5FF]/30 flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 text-[#00F5FF]" />
              </div>
              <div className="flex gap-1 px-3 py-2 rounded-2xl rounded-tl-sm bg-[#0B1120]/80 border border-white/10">
                <span className="w-2 h-2 rounded-full bg-[#00F5FF]/50 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 rounded-full bg-[#00F5FF]/50 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-[#00F5FF]/50 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          {/* Schedule Option */}
          {showScheduleForm && !meetingScheduled && (
            <div className="flex gap-2 animate-slide-up">
              <div className="flex-shrink-0 w-7 h-7 rounded-full bg-[#0B1120] border border-[#00F5FF]/30 flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 text-[#00F5FF]" />
              </div>
              <div className="max-w-[90%] bg-[#0B1120]/80 border border-[#00F5FF]/20 rounded-2xl rounded-tl-sm px-4 py-4">
                <p className="text-white mb-3">¡Veo que tienes interés! Completa tus datos:</p>
                <ScheduleForm onSubmit={handleScheduleMeeting} />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions */}
        <div className="px-4 py-2 border-t border-[#00F5FF]/5">
          <div className="flex flex-wrap gap-2">
            {CONFIG.QUICK_SUGGESTIONS.map((suggestion, idx) => (
              <button
                key={idx}
                onClick={() => sendMessage(suggestion)}
                className="px-3 py-1.5 text-xs text-[#9CA3AF] border border-[#00F5FF]/20 rounded-full hover:border-[#00F5FF]/50 hover:text-[#00F5FF] transition-all bg-[#00F5FF]/5"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <form onSubmit={handleSubmit} className="p-3 border-t border-[#00F5FF]/10 bg-[#0B1120]/80">
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Escribe tu mensaje..."
              className="flex-1 px-4 py-2.5 text-sm text-white bg-[#0B1120]/80 border border-[#00F5FF]/20 rounded-xl focus:outline-none focus:border-[#00F5FF]/50 focus:ring-1 focus:ring-[#00F5FF]/30 placeholder:text-[#9CA3AF]/50 transition-all"
              maxLength={1000}
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className="px-4 py-2.5 bg-gradient-to-r from-[#00F5FF] to-[#00C8D0] text-[#0B1120] rounded-xl hover:shadow-lg hover:shadow-[#00F5FF]/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

// ==========================================
// SUB-COMPONENTE: FORMULARIO DE AGENDA
// ==========================================
interface ScheduleFormProps {
  onSubmit: (data: {
    nombre: string;
    email: string;
    empresa: string;
    horario: string;
  }) => void;
}

const ScheduleForm: React.FC<ScheduleFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    empresa: '',
    horario: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <input
        type="text"
        placeholder="Tu nombre"
        required
        value={formData.nombre}
        onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
        className="w-full px-3 py-2 bg-[#0B1120]/80 border border-[#00F5FF]/20 rounded-lg text-white text-sm placeholder:text-[#9CA3AF]/50 focus:outline-none focus:border-[#00F5FF]/50"
      />
      <input
        type="email"
        placeholder="Tu correo"
        required
        value={formData.email}
        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
        className="w-full px-3 py-2 bg-[#0B1120]/80 border border-[#00F5FF]/20 rounded-lg text-white text-sm placeholder:text-[#9CA3AF]/50 focus:outline-none focus:border-[#00F5FF]/50"
      />
      <input
        type="text"
        placeholder="Nombre de tu empresa"
        required
        value={formData.empresa}
        onChange={(e) => setFormData({ ...formData, empresa: e.target.value })}
        className="w-full px-3 py-2 bg-[#0B1120]/80 border border-[#00F5FF]/20 rounded-lg text-white text-sm placeholder:text-[#9CA3AF]/50 focus:outline-none focus:border-[#00F5FF]/50"
      />
      <select
        required
        value={formData.horario}
        onChange={(e) => setFormData({ ...formData, horario: e.target.value })}
        className="w-full px-3 py-2 bg-[#0B1120]/80 border border-[#00F5FF]/20 rounded-lg text-white text-sm focus:outline-none focus:border-[#00F5FF]/50"
      >
        <option value="">Selecciona un horario</option>
        <option value="morning">Mañana (9:00 - 12:00)</option>
        <option value="afternoon">Tarde (12:00 - 17:00)</option>
        <option value="evening">Noche (17:00 - 19:00)</option>
      </select>
      <button
        type="submit"
        className="w-full px-4 py-2 bg-gradient-to-r from-[#00F5FF] to-[#00C8D0] text-[#0B1120] rounded-lg text-sm font-medium hover:shadow-lg hover:shadow-[#00F5FF]/30 transition-all flex items-center justify-center gap-2"
      >
        <Calendar className="w-4 h-4" />
        Confirmar reunión
      </button>
    </form>
  );
};

export default NexoraChatbot;
