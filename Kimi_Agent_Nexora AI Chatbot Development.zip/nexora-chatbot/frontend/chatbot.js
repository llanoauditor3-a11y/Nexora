/**
 * ==========================================
 * NEXORA CHATBOT - FRONTEND MODULE
 * ==========================================
 * 
 * Chatbot empresarial profesional con:
 * - Integración OpenAI via backend
 * - Calificación de leads
 * - UI futurista con glassmorphism
 * - Animaciones suaves
 * - Responsive design
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

(function() {
  'use strict';

  // ==========================================
  // CONFIGURACIÓN
  // ==========================================
  const CONFIG = {
    // URL del backend (cambiar en producción)
    API_URL: window.NEXORA_CHATBOT_API_URL || 'http://localhost:3001/api/chat',
    
    // Configuración del chatbot
    BOT_NAME: 'Nexora Assistant',
    BOT_AVATAR: '🤖',
    USER_AVATAR: '👤',
    
    // Colores de la marca
    COLORS: {
      primary: '#00F5FF',
      midnight: '#0B1120',
      darkBlue: '#0F172A',
      gray: '#9CA3AF',
    },
    
    // Mensaje de bienvenida
    WELCOME_MESSAGE: '¡Hola! Soy el asistente virtual de Nexora Analytics & AI. ¿En qué puedo ayudarte hoy?',
    
    // Sugerencias rápidas
    QUICK_SUGGESTIONS: [
      '¿Qué servicios ofrecen?',
      'Quiero una demo',
      '¿Cuáles son los precios?',
      'Agendar reunión'
    ],
    
    // Tiempo de simulación de typing (ms)
    TYPING_DELAY: 1000,
    
    // Máximo número de mensajes en historial
    MAX_HISTORY: 50,
  };

  // ==========================================
  // ESTADO DEL CHATBOT
  // ==========================================
  const state = {
    isOpen: false,
    isTyping: false,
    sessionId: null,
    messages: [],
    leadInfo: {},
    leadScore: 0,
    unreadCount: 0,
  };

  // ==========================================
  // UTILIDADES
  // ==========================================
  
  /**
   * Genera un UUID v4 para la sesión
   */
  function generateSessionId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /**
   * Sanitiza HTML para prevenir XSS
   */
  function sanitizeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  /**
   * Formatea la hora actual
   */
  function formatTime(date = new Date()) {
    return date.toLocaleTimeString('es-ES', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  }

  /**
   * Detecta si es dispositivo móvil
   */
  function isMobile() {
    return window.innerWidth < 768;
  }

  /**
   * Guarda el estado en localStorage
   */
  function saveState() {
    try {
      localStorage.setItem('nexora_chatbot_state', JSON.stringify({
        sessionId: state.sessionId,
        messages: state.messages.slice(-10), // Solo últimos 10 mensajes
        leadInfo: state.leadInfo,
        leadScore: state.leadScore,
      }));
    } catch (e) {
      console.warn('No se pudo guardar el estado:', e);
    }
  }

  /**
   * Carga el estado desde localStorage
   */
  function loadState() {
    try {
      const saved = localStorage.getItem('nexora_chatbot_state');
      if (saved) {
        const parsed = JSON.parse(saved);
        state.sessionId = parsed.sessionId || generateSessionId();
        state.messages = parsed.messages || [];
        state.leadInfo = parsed.leadInfo || {};
        state.leadScore = parsed.leadScore || 0;
      } else {
        state.sessionId = generateSessionId();
      }
    } catch (e) {
      console.warn('No se pudo cargar el estado:', e);
      state.sessionId = generateSessionId();
    }
  }

  // ==========================================
  // API CLIENT
  // ==========================================
  
  const api = {
    /**
     * Envía un mensaje al backend
     */
    async sendMessage(message) {
      const response = await fetch(CONFIG.API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: message,
          sessionId: state.sessionId,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Error en la comunicación');
      }

      return await response.json();
    },

    /**
     * Agenda una reunión
     */
    async scheduleMeeting(meetingData) {
      const response = await fetch(CONFIG.API_URL.replace('/chat', '/schedule'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionId: state.sessionId,
          ...meetingData,
        }),
      });

      return await response.json();
    },
  };

  // ==========================================
  // UI COMPONENTS
  // ==========================================
  
  const ui = {
    container: null,
    chatWindow: null,
    messagesContainer: null,
    input: null,
    toggleBtn: null,
    typingIndicator: null,

    /**
     * Inicializa la UI del chatbot
     */
    init() {
      this.createContainer();
      this.createToggleButton();
      this.createChatWindow();
      this.attachEventListeners();
      
      // Cargar mensajes previos si existen
      if (state.messages.length > 0) {
        this.renderMessages();
      } else {
        // Mensaje de bienvenida
        this.addMessage('bot', CONFIG.WELCOME_MESSAGE);
      }
    },

    /**
     * Crea el contenedor principal
     */
    createContainer() {
      this.container = document.createElement('div');
      this.container.id = 'nexora-chatbot-container';
      this.container.className = 'fixed bottom-4 right-4 z-50 font-inter';
      document.getElementById('nexora-chatbot').appendChild(this.container);
    },

    /**
     * Crea el botón flotante de toggle
     */
    createToggleButton() {
      this.toggleBtn = document.createElement('button');
      this.toggleBtn.className = `
        relative w-14 h-14 rounded-full 
        bg-gradient-to-r from-nexora-cyan to-nexora-cyan-dark
        text-nexora-midnight
        shadow-lg shadow-nexora-cyan/30
        hover:shadow-xl hover:shadow-nexora-cyan/50
        hover:scale-105
        transition-all duration-300
        flex items-center justify-center
        animate-pulse-glow
      `;
      this.toggleBtn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <span id="chatbot-unread-badge" class="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-bold hidden">
          0
        </span>
      `;
      this.toggleBtn.setAttribute('aria-label', 'Abrir chat');
      this.container.appendChild(this.toggleBtn);
    },

    /**
     * Crea la ventana de chat
     */
    createChatWindow() {
      this.chatWindow = document.createElement('div');
      this.chatWindow.className = `
        fixed bottom-20 right-4
        w-[90vw] max-w-[400px] 
        glass rounded-2xl
        shadow-2xl shadow-black/50
        overflow-hidden
        transition-all duration-500
        origin-bottom-right
        ${state.isOpen ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-4 pointer-events-none'}
      `;
      
      // Ajustar posición en móvil
      if (isMobile()) {
        this.chatWindow.className = this.chatWindow.className.replace('bottom-20 right-4', 'bottom-0 left-0 right-0 w-full max-w-none rounded-t-2xl');
      }

      this.chatWindow.innerHTML = `
        <!-- Header -->
        <div class="flex items-center justify-between px-4 py-3 border-b border-nexora-cyan/10 bg-nexora-dark-blue/50">
          <div class="flex items-center gap-3">
            <div class="relative">
              <div class="absolute inset-0 bg-nexora-cyan/30 rounded-full blur-md animate-pulse"></div>
              <div class="relative w-10 h-10 rounded-full bg-gradient-to-br from-nexora-cyan/30 to-nexora-cyan/10 border border-nexora-cyan/40 flex items-center justify-center text-xl">
                ${CONFIG.BOT_AVATAR}
              </div>
              <span class="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-nexora-dark-blue"></span>
            </div>
            <div>
              <span class="text-sm font-medium text-white block">${CONFIG.BOT_NAME}</span>
              <span class="text-xs text-nexora-gray flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                En línea ahora
              </span>
            </div>
          </div>
          <div class="flex items-center gap-1">
            <button id="chatbot-minimize" class="p-2 text-nexora-gray hover:text-nexora-cyan hover:bg-nexora-cyan/10 rounded-lg transition-all">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>
            </button>
            <button id="chatbot-close" class="p-2 text-nexora-gray hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
          </div>
        </div>

        <!-- Messages Area -->
        <div id="chatbot-messages" class="h-80 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-gradient-to-b from-nexora-midnight/80 to-nexora-dark-blue/50">
          <!-- Info Banner -->
          <div class="bg-nexora-cyan/5 border border-nexora-cyan/10 rounded-xl p-3 mb-2">
            <p class="text-xs text-nexora-gray text-center">
              Este asistente puede ayudarte con información sobre nuestros servicios y agendar una reunión.
            </p>
          </div>
        </div>

        <!-- Typing Indicator -->
        <div id="chatbot-typing" class="hidden px-4 py-2">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-full bg-nexora-dark-blue border border-nexora-cyan/30 flex items-center justify-center text-xs">
              ${CONFIG.BOT_AVATAR}
            </div>
            <div class="flex gap-1 px-3 py-2 rounded-2xl rounded-tl-sm bg-nexora-dark-blue/80 border border-white/10">
              <span class="w-2 h-2 rounded-full bg-nexora-cyan/50 typing-dot"></span>
              <span class="w-2 h-2 rounded-full bg-nexora-cyan/50 typing-dot"></span>
              <span class="w-2 h-2 rounded-full bg-nexora-cyan/50 typing-dot"></span>
            </div>
          </div>
        </div>

        <!-- Quick Suggestions -->
        <div id="chatbot-suggestions" class="px-4 py-2 border-t border-nexora-cyan/5">
          <div class="flex flex-wrap gap-2">
            ${CONFIG.QUICK_SUGGESTIONS.map(s => `
              <button class="quick-suggestion px-3 py-1.5 text-xs text-nexora-gray border border-nexora-cyan/20 rounded-full hover:border-nexora-cyan/50 hover:text-nexora-cyan transition-all bg-nexora-cyan/5">
                ${s}
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Input Area -->
        <div class="p-3 border-t border-nexora-cyan/10 bg-nexora-dark-blue/80">
          <div class="flex gap-2">
            <input 
              id="chatbot-input" 
              type="text" 
              placeholder="Escribe tu mensaje..."
              class="flex-1 px-4 py-2.5 text-sm text-white bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-xl focus:outline-none focus:border-nexora-cyan/50 focus:ring-1 focus:ring-nexora-cyan/30 placeholder:text-nexora-gray/50 transition-all"
              maxlength="1000"
            >
            <button 
              id="chatbot-send"
              class="px-4 py-2.5 bg-gradient-to-r from-nexora-cyan to-nexora-cyan-dark text-nexora-midnight rounded-xl hover:shadow-lg hover:shadow-nexora-cyan/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4 20-7z"/></svg>
            </button>
          </div>
        </div>
      `;

      this.container.appendChild(this.chatWindow);

      // Guardar referencias
      this.messagesContainer = this.chatWindow.querySelector('#chatbot-messages');
      this.input = this.chatWindow.querySelector('#chatbot-input');
      this.typingIndicator = this.chatWindow.querySelector('#chatbot-typing');
    },

    /**
     * Adjunta event listeners
     */
    attachEventListeners() {
      // Toggle button
      this.toggleBtn.addEventListener('click', () => this.toggle());

      // Close button
      this.chatWindow.querySelector('#chatbot-close').addEventListener('click', () => this.close());

      // Minimize button
      this.chatWindow.querySelector('#chatbot-minimize').addEventListener('click', () => this.close());

      // Send button
      const sendBtn = this.chatWindow.querySelector('#chatbot-send');
      sendBtn.addEventListener('click', () => this.handleSend());

      // Input enter key
      this.input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.handleSend();
        }
      });

      // Quick suggestions
      this.chatWindow.querySelectorAll('.quick-suggestion').forEach(btn => {
        btn.addEventListener('click', () => {
          this.input.value = btn.textContent.trim();
          this.handleSend();
        });
      });

      // Cerrar al hacer clic fuera (en desktop)
      document.addEventListener('click', (e) => {
        if (state.isOpen && !this.container.contains(e.target)) {
          this.close();
        }
      });

      // Resize handler
      window.addEventListener('resize', () => {
        this.handleResize();
      });
    },

    /**
     * Maneja el resize de la ventana
     */
    handleResize() {
      if (isMobile() && state.isOpen) {
        this.chatWindow.classList.add('fixed', 'inset-x-0', 'bottom-0', 'w-full', 'max-w-none', 'rounded-t-2xl');
        this.chatWindow.classList.remove('right-4', 'w-[90vw]', 'max-w-[400px]', 'rounded-2xl');
      } else if (!isMobile() && state.isOpen) {
        this.chatWindow.classList.remove('fixed', 'inset-x-0', 'bottom-0', 'w-full', 'max-w-none', 'rounded-t-2xl');
        this.chatWindow.classList.add('right-4', 'w-[90vw]', 'max-w-[400px]', 'rounded-2xl');
      }
    },

    /**
     * Abre/cierra el chat
     */
    toggle() {
      state.isOpen = !state.isOpen;
      this.updateVisibility();
      
      if (state.isOpen) {
        state.unreadCount = 0;
        this.updateUnreadBadge();
        setTimeout(() => this.input.focus(), 300);
      }
    },

    /**
     * Cierra el chat
     */
    close() {
      state.isOpen = false;
      this.updateVisibility();
    },

    /**
     * Actualiza la visibilidad de la ventana
     */
    updateVisibility() {
      if (state.isOpen) {
        this.chatWindow.classList.remove('opacity-0', 'scale-95', 'translate-y-4', 'pointer-events-none');
        this.chatWindow.classList.add('opacity-100', 'scale-100', 'translate-y-0');
        this.toggleBtn.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        `;
      } else {
        this.chatWindow.classList.add('opacity-0', 'scale-95', 'translate-y-4', 'pointer-events-none');
        this.chatWindow.classList.remove('opacity-100', 'scale-100', 'translate-y-0');
        this.toggleBtn.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span id="chatbot-unread-badge" class="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-bold ${state.unreadCount > 0 ? '' : 'hidden'}">
            ${state.unreadCount}
          </span>
        `;
      }
    },

    /**
     * Actualiza el badge de mensajes no leídos
     */
    updateUnreadBadge() {
      const badge = this.toggleBtn.querySelector('#chatbot-unread-badge');
      if (badge) {
        badge.textContent = state.unreadCount;
        badge.classList.toggle('hidden', state.unreadCount === 0);
      }
    },

    /**
     * Muestra el indicador de typing
     */
    showTyping() {
      state.isTyping = true;
      this.typingIndicator.classList.remove('hidden');
      this.scrollToBottom();
    },

    /**
     * Oculta el indicador de typing
     */
    hideTyping() {
      state.isTyping = false;
      this.typingIndicator.classList.add('hidden');
    },

    /**
     * Agrega un mensaje a la UI
     */
    addMessage(type, text, metadata = {}) {
      const message = {
        id: Date.now(),
        type,
        text,
        timestamp: new Date(),
        ...metadata,
      };

      state.messages.push(message);
      
      // Limitar historial
      if (state.messages.length > CONFIG.MAX_HISTORY) {
        state.messages = state.messages.slice(-CONFIG.MAX_HISTORY);
      }

      this.renderMessage(message);
      this.scrollToBottom();
      saveState();

      // Incrementar contador si es mensaje del bot y chat cerrado
      if (type === 'bot' && !state.isOpen) {
        state.unreadCount++;
        this.updateUnreadBadge();
      }
    },

    /**
     * Renderiza un mensaje individual
     */
    renderMessage(message) {
      const isBot = message.type === 'bot';
      const div = document.createElement('div');
      div.className = `flex gap-2 ${isBot ? '' : 'flex-row-reverse'} animate-slide-up`;
      
      div.innerHTML = `
        <!-- Avatar -->
        <div class="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm ${
          isBot 
            ? 'bg-nexora-dark-blue border border-nexora-cyan/30' 
            : 'bg-nexora-cyan/20'
        }">
          ${isBot ? CONFIG.BOT_AVATAR : CONFIG.USER_AVATAR}
        </div>
        
        <!-- Message Bubble -->
        <div class="max-w-[75%] ${
          isBot 
            ? 'bg-nexora-dark-blue/80 border border-white/10 text-nexora-gray-light rounded-2xl rounded-tl-sm' 
            : 'bg-gradient-to-r from-nexora-cyan/20 to-nexora-cyan/5 border border-nexora-cyan/30 text-white rounded-2xl rounded-tr-sm'
        } px-3 py-2 text-sm">
          <p class="leading-relaxed">${sanitizeHTML(message.text)}</p>
          <span class="text-[10px] ${isBot ? 'text-nexora-gray/60' : 'text-nexora-cyan/60'} mt-1 block">
            ${formatTime(message.timestamp)}
          </span>
        </div>
      `;

      this.messagesContainer.appendChild(div);
    },

    /**
     * Renderiza todos los mensajes del historial
     */
    renderMessages() {
      this.messagesContainer.innerHTML = `
        <div class="bg-nexora-cyan/5 border border-nexora-cyan/10 rounded-xl p-3 mb-2">
          <p class="text-xs text-nexora-gray text-center">
            Este asistente puede ayudarte con información sobre nuestros servicios y agendar una reunión.
          </p>
        </div>
      `;
      
      state.messages.forEach(msg => this.renderMessage(msg));
    },

    /**
     * Scroll al final de los mensajes
     */
    scrollToBottom() {
      setTimeout(() => {
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
      }, 50);
    },

    /**
     * Maneja el envío de mensaje
     */
    async handleSend() {
      const text = this.input.value.trim();
      if (!text || state.isTyping) return;

      // Agregar mensaje del usuario
      this.addMessage('user', text);
      this.input.value = '';

      // Mostrar typing
      this.showTyping();

      try {
        // Enviar al backend
        const response = await api.sendMessage(text);
        
        // Simular delay natural
        await new Promise(resolve => setTimeout(resolve, CONFIG.TYPING_DELAY));
        
        // Ocultar typing y mostrar respuesta
        this.hideTyping();
        this.addMessage('bot', response.response, {
          leadScore: response.leadScore,
          isLeadQualified: response.isLeadQualified,
        });

        // Actualizar info del lead
        if (response.leadInfo) {
          state.leadInfo = response.leadInfo;
          state.leadScore = response.leadScore;
          saveState();
        }

        // Si el lead está calificado, mostrar opción de agendar
        if (response.isLeadQualified && !state.meetingScheduled) {
          setTimeout(() => {
            this.showScheduleOption();
          }, 500);
        }

      } catch (error) {
        this.hideTyping();
        this.addMessage('bot', 'Lo siento, tuve un problema al procesar tu mensaje. ¿Podrías intentar de nuevo?');
        console.error('Error:', error);
      }
    },

    /**
     * Muestra opción para agendar reunión
     */
    showScheduleOption() {
      const div = document.createElement('div');
      div.className = 'flex gap-2 animate-slide-up';
      div.innerHTML = `
        <div class="flex-shrink-0 w-7 h-7 rounded-full bg-nexora-dark-blue border border-nexora-cyan/30 flex items-center justify-center text-sm">
          ${CONFIG.BOT_AVATAR}
        </div>
        <div class="max-w-[75%] bg-gradient-to-r from-green-500/20 to-green-500/5 border border-green-500/30 rounded-2xl rounded-tl-sm px-3 py-3 text-sm">
          <p class="text-white mb-2">¡Veo que tienes interés genuino! ¿Te gustaría agendar una reunión con nuestro equipo?</p>
          <button id="schedule-meeting-btn" class="w-full px-4 py-2 bg-green-500/20 hover:bg-green-500/30 border border-green-500/50 rounded-lg text-green-400 text-sm font-medium transition-all flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            Agendar reunión gratuita
          </button>
        </div>
      `;
      
      this.messagesContainer.appendChild(div);
      this.scrollToBottom();

      // Event listener para el botón
      div.querySelector('#schedule-meeting-btn').addEventListener('click', () => {
        this.showScheduleForm();
      });
    },

    /**
     * Muestra el formulario para agendar
     */
    showScheduleForm() {
      const div = document.createElement('div');
      div.className = 'flex gap-2 animate-slide-up';
      div.innerHTML = `
        <div class="flex-shrink-0 w-7 h-7 rounded-full bg-nexora-dark-blue border border-nexora-cyan/30 flex items-center justify-center text-sm">
          ${CONFIG.BOT_AVATAR}
        </div>
        <div class="max-w-[90%] bg-nexora-dark-blue/80 border border-nexora-cyan/20 rounded-2xl rounded-tl-sm px-4 py-4 text-sm">
          <p class="text-white mb-3">Perfecto, completa tus datos:</p>
          <form id="schedule-form" class="space-y-2">
            <input type="text" name="nombre" placeholder="Tu nombre" required
              class="w-full px-3 py-2 bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-lg text-white text-sm placeholder:text-nexora-gray/50 focus:outline-none focus:border-nexora-cyan/50">
            <input type="email" name="email" placeholder="Tu correo" required
              class="w-full px-3 py-2 bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-lg text-white text-sm placeholder:text-nexora-gray/50 focus:outline-none focus:border-nexora-cyan/50">
            <input type="text" name="empresa" placeholder="Nombre de tu empresa" required
              class="w-full px-3 py-2 bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-lg text-white text-sm placeholder:text-nexora-gray/50 focus:outline-none focus:border-nexora-cyan/50">
            <select name="horario" required
              class="w-full px-3 py-2 bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-lg text-white text-sm focus:outline-none focus:border-nexora-cyan/50">
              <option value="">Selecciona un horario</option>
              <option value="morning">Mañana (9:00 - 12:00)</option>
              <option value="afternoon">Tarde (12:00 - 17:00)</option>
              <option value="evening">Noche (17:00 - 19:00)</option>
            </select>
            <button type="submit" 
              class="w-full px-4 py-2 bg-gradient-to-r from-nexora-cyan to-nexora-cyan-dark text-nexora-midnight rounded-lg text-sm font-medium hover:shadow-lg hover:shadow-nexora-cyan/30 transition-all">
              Confirmar reunión
            </button>
          </form>
        </div>
      `;
      
      this.messagesContainer.appendChild(div);
      this.scrollToBottom();

      // Event listener del formulario
      div.querySelector('#schedule-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);
        
        await this.handleScheduleSubmit(data);
      });
    },

    /**
     * Maneja el envío del formulario de agenda
     */
    async handleScheduleSubmit(data) {
      try {
        const response = await api.scheduleMeeting({
          nombre: data.nombre,
          email: data.email,
          empresa: data.empresa,
          horario: data.horario,
          date: new Date(Date.now() + 86400000).toISOString(), // Mañana
        });

        if (response.success) {
          state.meetingScheduled = true;
          
          this.addMessage('bot', `¡Excelente ${data.nombre}! Tu reunión ha sido agendada. Te enviaremos un correo de confirmación a ${data.email} con el enlace de la videollamada.`);
          
          // Actualizar lead info
          state.leadInfo = {
            ...state.leadInfo,
            nombre: data.nombre,
            email: data.email,
            empresa: data.empresa,
          };
          saveState();
        }
      } catch (error) {
        this.addMessage('bot', 'Lo siento, hubo un problema al agendar la reunión. Por favor intenta más tarde o contáctanos por WhatsApp.');
      }
    },
  };

  // ==========================================
  // INICIALIZACIÓN
  // ==========================================
  
  function init() {
    // Cargar estado previo
    loadState();
    
    // Inicializar UI
    ui.init();
    
    console.log('🤖 Nexora Chatbot inicializado');
    console.log('📊 Session ID:', state.sessionId);
  }

  // Iniciar cuando el DOM esté listo
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Exponer API global para debugging
  window.NexoraChatbot = {
    state,
    config: CONFIG,
    ui,
    api,
  };

})();
