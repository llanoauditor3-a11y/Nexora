/**
 * ==========================================
 * NEXORA CHATBOT - BACKEND SERVER
 * ==========================================
 * 
 * Servidor Express profesional para chatbot empresarial
 * con integración OpenAI, calificación de leads, datos de 
 * cotizaciones y seguridad enterprise.
 * 
 * @author Nexora Analytics & AI
 * @version 2.0.0
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const OpenAI = require('openai');
const winston = require('winston');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

// Importar datos de pricing
const pricingData = require('./data/pricing');

// ==========================================
// CONFIGURACIÓN DE LOGGING
// ==========================================
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'nexora-chatbot' },
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ],
});

// ==========================================
// INICIALIZACIÓN DE EXPRESS
// ==========================================
const app = express();
const PORT = process.env.PORT || 3001;

// ==========================================
// MIDDLEWARE DE SEGURIDAD
// ==========================================
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      connectSrc: ["'self'", process.env.FRONTEND_URL || "*"],
    },
  },
}));

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: {
    error: 'Demasiadas solicitudes. Por favor intenta más tarde.',
    retryAfter: '15 minutos'
  },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// ==========================================
// INICIALIZACIÓN DE OPENAI
// ==========================================
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ==========================================
// BASE DE DATOS EN MEMORIA
// ==========================================
const conversations = new Map();
const leads = new Map();

// ==========================================
// PROMPT DEL SISTEMA - PERSONALIDAD NEXORA
// ==========================================
const SYSTEM_PROMPT = `Eres el Asistente Estratégico de Nexora Analytics & AI, una empresa líder en análisis de datos, inteligencia artificial y consultoría predictiva empresarial. Tu misión es calificar prospectos, responder preguntas y guiar conversaciones hacia una reunión de ventas.

🎯 TU MISIÓN PRINCIPAL:
1. Responder preguntas sobre servicios de manera profesional y detallada
2. Calificar prospectos (capturar nombre, empresa, email, industria, tamaño)
3. Manejar preguntas sobre precios y cotizaciones con transparencia
4. Guiar la conversación hacia agendar una reunión

📋 SERVICIOS DE NEXORA:

1️⃣ ANÁLISIS DE DATOS
   • Dashboards en tiempo real personalizados
   • KPIs y métricas de negocio
   • Reportes automatizados
   • Visualizaciones interactivas
   • Precios: $15,000 - $150,000+ USD según complejidad

2️⃣ INTELIGENCIA ARTIFICIAL / MACHINE LEARNING
   • Modelos predictivos personalizados
   • Procesamiento de lenguaje natural (NLP)
   • Visión por computadora
   • AutoML y MLOps
   • Precios: $25,000 - $300,000+ USD según modelo

3️⃣ CONSULTORÍA PREDICTIVA
   • Forecasting de ventas y demanda
   • Análisis de riesgos
   • Optimización de recursos
   • Simulaciones de escenarios
   • Precios: $20,000 - $200,000+ USD según alcance

💰 PLANES Y PRECIOS (información precisa):

📊 PLAN STARTER: $2,500 USD/mes
   • Para startups y PYMES
   • Hasta 3 dashboards, 1 fuente de datos
   • Hasta 5 usuarios
   • Implementación: $5,000 USD
   • Descuento anual: 20%

🏢 PLAN BUSINESS: $7,500 USD/mes
   • Para empresas en crecimiento
   • Dashboards ilimitados, hasta 5 fuentes
   • Hasta 25 usuarios, 1 modelo ML incluido
   • Implementación: $15,000 USD
   • Descuento anual: 25%

🏭 PLAN ENTERPRISE: Desde $20,000 USD/mes
   • Para grandes corporaciones
   • Todo ilimitado + desarrollos custom
   • Soporte 24/7 + account manager dedicado
   • Implementación: según alcance
   • Descuento anual: 30%

📋 COTIZACIONES POR PROYECTO:
• Análisis de Datos: $15k-$150k+ (2-16 semanas)
• IA/Machine Learning: $25k-$300k+ (4-24 semanas)
• Consultoría Predictiva: $20k-$200k+ (3-20 semanas)

Los precios varían según: volumen de datos, complejidad, número de usuarios, integraciones requeridas y timeline.

🗣️ TONO Y ESTILO:
• Profesional, cercano y orientado a resultados
• Tecnológico y futurista
• Siempre en español (a menos que el usuario escriba en otro idioma)
• Usa emojis ocasionalmente para dar calidez
• Respuestas concisas pero completas (2-4 párrafos máximo)

🔍 PROCESO DE CALIFICACIÓN DE LEADS:
Obtén gradualmente esta información (una pregunta a la vez):
1. Nombre de la persona
2. Nombre de la empresa
3. Correo electrónico
4. Industria/sector
5. Tamaño de la empresa (empleados)
6. Servicio de interés
7. Presupuesto estimado (opcional)

💡 ESTRATEGIA CONVERSACIONAL:
• NO pidas toda la información de golpe
• Valida el interés antes de profundizar
• Ofrece valor antes de pedir datos
• Cuando el usuario pregunte por precios, usa la información precisa de arriba
• Si detectas interés genuino (pregunta sobre precios o servicios específicos), propón agendar una reunión
• Maneja objeciones con empatía

📅 PARA AGENDAR REUNIONES:
Horarios disponibles:
• Lunes a Viernes: 9:00 - 18:00 (CDMX)
• Duración: 30 minutos
• Modalidad: Zoom o Google Meet

❌ RESTRICCIONES IMPORTANTES:
• NO inventes precios fuera de los rangos indicados arriba
• NO prometas resultados específicos sin análisis previo
• NO compartas información interna o confidencial
• Si no sabes algo, ofrece conectar con un especialista

✅ SIEMPRE:
• Saluda profesionalmente en la primera interacción
• Confirma que entendiste la pregunta antes de responder
• Sugiere próximos pasos claros
• Cuando hables de precios, menciona que pueden variar según requerimientos específicos
• Ofrece una cotización personalizada cuando el usuario muestre interés genuino`;

// ==========================================
// FUNCIONES AUXILIARES
// ==========================================
function sanitizeInput(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/[<>]/g, '')
    .trim()
    .substring(0, 1000);
}

function detectIntent(message) {
  const lowerMsg = message.toLowerCase();
  
  const intents = {
    servicios: /servicio|ofrecen|hacen|producto|solución|qué hacen/i,
    precios: /precio|costo|tarifa|presupuesto|cuánto|cuesta|valor|inversión|plan/i,
    cotizacion: /cotización|cotizar|quote|presupuesto|cuánto me costaría|cuánto valdría/i,
    agendar: /agendar|reunión|cita|demo|demostración|llamada|videollamada|calendario|hablar/i,
    contacto: /contacto|email|correo|teléfono|whatsapp|hablar con alguien/i,
    analisis_datos: /análisis de datos|dashboard|kpi|reporte|visualización|tablero/i,
    ia: /inteligencia artificial|ia|machine learning|ml|nlp|visión computadora|modelo predictivo/i,
    consultoria: /consultoría|predictiva|forecasting|predicción|pronóstico/i,
    starter: /starter|básico|inicial|startup|pyme|pequeño/i,
    business: /business|mediano|empresa|crecimiento/i,
    enterprise: /enterprise|corporativo|grande|institución/i,
    despedida: /adios|hasta luego|gracias|bye|chao|nos vemos/i,
    saludo: /hola|buenos días|buenas tardes|buenas noches|hey|hi|saludos/i,
  };

  for (const [intent, regex] of Object.entries(intents)) {
    if (regex.test(lowerMsg)) return intent;
  }
  
  return 'general';
}

function extractLeadInfo(message, conversation) {
  const info = { ...conversation.leadInfo };
  const lowerMsg = message.toLowerCase().trim();
  
  // Detectar email
  const emailMatch = message.match(/[\w.-]+@[\w.-]+\.\w+/);
  if (emailMatch && !info.email) {
    info.email = emailMatch[0];
  }
  
  // Detectar nombre
  const namePatterns = [
    /(?:me llamo|soy|mi nombre es|mi nombre)\s+([A-Za-zÁÉÍÓÚáéíóúñÑ\s]+?)(?:\s+y\s+|\s*,|\s*\.|$|\s+de\s+)/i,
    /(?:nombre:)\s*([A-Za-zÁÉÍÓÚáéíóúñÑ\s]+?)(?:\s*,|\s*\.|$)/i,
  ];
  
  for (const pattern of namePatterns) {
    const match = message.match(pattern);
    if (match && !info.nombre) {
      info.nombre = match[1].trim();
      break;
    }
  }
  
  // Detectar empresa
  const companyPatterns = [
    /(?:trabajo en|mi empresa es|soy de|empresa:|de la empresa|represento a)\s+([A-Za-zÁÉÍÓÚáéíóúñÑ\s\.]+?)(?:\s+y\s+|\s*,|\s*\.|$)/i,
  ];
  
  for (const pattern of companyPatterns) {
    const match = message.match(pattern);
    if (match && !info.empresa) {
      info.empresa = match[1].trim();
      break;
    }
  }
  
  // Detectar industria
  const industrias = [
    'tecnología', 'tech', 'software', 'finanzas', 'banca', 'salud', 
    'healthcare', 'retail', 'ecommerce', 'manufactura', 'educación', 
    'logística', 'consultoría', 'telecomunicaciones', 'energía', 
    'seguros', 'inmobiliaria', 'retail', 'alimentos', 'automotriz'
  ];
  
  for (const industria of industrias) {
    if (lowerMsg.includes(industria) && !info.industria) {
      info.industria = industria.charAt(0).toUpperCase() + industria.slice(1);
      break;
    }
  }
  
  // Detectar tamaño de empresa
  const sizePatterns = [
    { regex: /(\d+)\s*(?:empleados|personas|colaboradores|trabajadores)/i, key: 'tamaño' },
    { regex: /(pequeña|mediana|grande|startup|empresa pequeña|pyme|corporativo)/i, key: 'tamañoCategoria' },
  ];
  
  for (const { regex, key } of sizePatterns) {
    const match = message.match(regex);
    if (match && !info[key]) {
      info[key] = match[1];
      break;
    }
  }
  
  // Detectar servicio de interés
  const servicios = {
    'analisis_datos': /análisis de datos|dashboard|visualización|kpi|reporte/i,
    'ia': /inteligencia artificial|machine learning|ia|ml|modelo predictivo|nlp/i,
    'consultoria': /consultoría|predictiva|forecasting/i,
  };
  
  for (const [servicio, regex] of Object.entries(servicios)) {
    if (regex.test(lowerMsg) && !info.servicioInteres) {
      info.servicioInteres = servicio;
      break;
    }
  }
  
  // Detectar presupuesto
  const budgetMatch = message.match(/(?:presupuesto|budget|invertir|disponible)\s*(?:de|:)?\s*\$?([\d,]+(?:\.\d{2})?)\s*(k|mil|miles|millones|millón)?/i);
  if (budgetMatch && !info.presupuesto) {
    let amount = budgetMatch[1].replace(/,/g, '');
    const multiplier = budgetMatch[2];
    if (multiplier) {
      if (multiplier.toLowerCase().includes('m')) amount *= 1000000;
      else if (multiplier.toLowerCase().includes('k') || multiplier.toLowerCase().includes('mil')) amount *= 1000;
    }
    info.presupuesto = `$${amount} USD`;
  }
  
  return info;
}

function calculateLeadScore(leadInfo) {
  let score = 0;
  const weights = {
    nombre: 15,
    email: 20,
    empresa: 20,
    industria: 10,
    tamaño: 10,
    servicioInteres: 15,
    presupuesto: 10,
  };
  
  for (const [field, weight] of Object.entries(weights)) {
    if (leadInfo[field]) score += weight;
  }
  
  return Math.min(score, 100);
}

// ==========================================
// ENDPOINTS API
// ==========================================

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    service: 'nexora-chatbot-backend',
    version: '2.0.0',
    pricingData: {
      plansAvailable: Object.keys(pricingData.MONTHLY_PLANS).length,
      servicesAvailable: Object.keys(pricingData.PROJECT_SERVICES).length,
    }
  });
});

// Endpoint para obtener información de pricing
app.get('/api/pricing', (req, res) => {
  res.json({
    success: true,
    data: {
      monthlyPlans: pricingData.MONTHLY_PLANS,
      projectServices: pricingData.PROJECT_SERVICES,
      addOns: pricingData.ADD_ONS,
      pricingFactors: pricingData.PRICING_FACTORS,
    }
  });
});

// Endpoint para cotización estimada
app.post('/api/pricing/estimate', (req, res) => {
  const { service, tier, factors } = req.body;
  
  const estimate = pricingData.estimateProject(service, tier, factors);
  
  if (!estimate) {
    return res.status(400).json({
      error: 'Servicio o tier no válido',
      availableServices: Object.keys(pricingData.PROJECT_SERVICES),
    });
  }
  
  res.json({
    success: true,
    estimate,
  });
});

// Endpoint principal del chatbot
app.post('/api/chat', [
  body('message')
    .trim()
    .notEmpty().withMessage('El mensaje es requerido')
    .isLength({ max: 1000 }).withMessage('El mensaje es demasiado largo'),
  body('sessionId')
    .optional()
    .isUUID().withMessage('Session ID inválido'),
], async (req, res) => {
  const startTime = Date.now();
  
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      logger.warn('Validación fallida', { errors: errors.array() });
      return res.status(400).json({
        error: 'Datos inválidos',
        details: errors.array()
      });
    }

    const { message, sessionId = uuidv4() } = req.body;
    const sanitizedMessage = sanitizeInput(message);
    
    logger.info('Nueva solicitud de chat', { 
      sessionId, 
      messageLength: sanitizedMessage.length,
      ip: req.ip 
    });

    // Obtener o crear conversación
    let conversation = conversations.get(sessionId);
    if (!conversation) {
      conversation = {
        sessionId,
        messages: [],
        leadInfo: {},
        leadScore: 0,
        createdAt: new Date(),
        lastActivity: new Date(),
      };
      conversations.set(sessionId, conversation);
    }

    conversation.lastActivity = new Date();

    // Detectar intención
    const intent = detectIntent(sanitizedMessage);
    logger.info('Intención detectada', { sessionId, intent });

    // Extraer información de lead
    conversation.leadInfo = extractLeadInfo(sanitizedMessage, conversation);
    conversation.leadScore = calculateLeadScore(conversation.leadInfo);

    // Preparar mensajes para OpenAI
    const messagesForAI = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...conversation.messages.slice(-10),
      { role: 'user', content: sanitizedMessage }
    ];

    // Llamada a OpenAI
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: messagesForAI,
      temperature: 0.7,
      max_tokens: 600,
      presence_penalty: 0.3,
      frequency_penalty: 0.3,
    });

    const aiResponse = completion.choices[0]?.message?.content || 
      'Lo siento, no pude procesar tu mensaje. ¿Podrías intentar de nuevo?';

    // Guardar en historial
    conversation.messages.push(
      { role: 'user', content: sanitizedMessage },
      { role: 'assistant', content: aiResponse }
    );

    if (conversation.messages.length > 20) {
      conversation.messages = conversation.messages.slice(-20);
    }

    // Guardar lead si tiene score alto
    if (conversation.leadScore >= 50 && !leads.has(sessionId)) {
      leads.set(sessionId, {
        ...conversation.leadInfo,
        sessionId,
        score: conversation.leadScore,
        createdAt: new Date(),
      });
      logger.info('Nuevo lead calificado', { sessionId, score: conversation.leadScore });
    }

    const responseTime = Date.now() - startTime;
    logger.info('Respuesta generada', { sessionId, responseTime, tokens: completion.usage?.total_tokens });

    res.json({
      success: true,
      response: aiResponse,
      sessionId,
      intent,
      leadInfo: conversation.leadInfo,
      leadScore: conversation.leadScore,
      isLeadQualified: conversation.leadScore >= 50,
      metadata: {
        responseTimeMs: responseTime,
        tokensUsed: completion.usage?.total_tokens,
        model: completion.model,
      }
    });

  } catch (error) {
    logger.error('Error en chat endpoint', { 
      error: error.message, 
      stack: error.stack,
      sessionId: req.body?.sessionId 
    });

    if (error.code === 'insufficient_quota') {
      return res.status(429).json({
        error: 'Servicio temporalmente no disponible. Por favor contacta a soporte.',
        code: 'QUOTA_EXCEEDED'
      });
    }

    if (error.code === 'rate_limit_exceeded') {
      return res.status(429).json({
        error: 'Demasiadas solicitudes. Por favor espera un momento.',
        code: 'RATE_LIMIT'
      });
    }

    res.status(500).json({
      error: 'Error interno del servidor. Por favor intenta más tarde.',
      code: 'INTERNAL_ERROR'
    });
  }
});

app.get('/api/leads/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const lead = leads.get(sessionId);
  
  if (!lead) {
    return res.status(404).json({ error: 'Lead no encontrado' });
  }
  
  res.json({ success: true, lead });
});

app.get('/api/leads', (req, res) => {
  const leadsArray = Array.from(leads.values());
  res.json({ 
    success: true, 
    count: leadsArray.length,
    leads: leadsArray 
  });
});

app.post('/api/schedule', [
  body('sessionId').isUUID(),
  body('date').isISO8601(),
  body('email').isEmail(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { sessionId, date, email, nombre } = req.body;
  
  logger.info('Reunión agendada', { sessionId, date, email });
  
  res.json({
    success: true,
    message: 'Reunión agendada exitosamente',
    meeting: {
      sessionId,
      date,
      email,
      nombre,
      meetingLink: 'https://meet.nexora.ai/demo-' + sessionId.slice(0, 8),
      status: 'confirmed'
    }
  });
});

// Manejo de errores global
app.use((err, req, res, next) => {
  logger.error('Error no manejado', { error: err.message, stack: err.stack });
  res.status(500).json({
    error: 'Error interno del servidor',
    code: 'INTERNAL_ERROR'
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  logger.info(`🚀 Servidor Nexora Chatbot iniciado en puerto ${PORT}`);
  logger.info(`📊 Health check: http://localhost:${PORT}/api/health`);
  logger.info(`💬 Chat endpoint: http://localhost:${PORT}/api/chat`);
  logger.info(`💰 Pricing endpoint: http://localhost:${PORT}/api/pricing`);
});

module.exports = app;
