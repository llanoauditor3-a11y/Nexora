/**
 * ==========================================
 * NEXORA PRICING DATA
 * ==========================================
 * 
 * Datos de cotizaciones y precios para el chatbot.
 * Esta información es utilizada por el sistema para responder
 * preguntas sobre precios de manera precisa.
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

// ==========================================
// PLANES MENSUALES
// ==========================================
const MONTHLY_PLANS = {
  starter: {
    name: 'Starter',
    price: 2500,
    currency: 'USD',
    period: 'mes',
    description: 'Ideal para startups y PYMES que comienzan su transformación digital',
    features: [
      'Hasta 3 dashboards personalizados',
      '1 fuente de datos',
      'Hasta 5 usuarios',
      'Soporte vía chat y email',
      'Actualizaciones mensuales',
      'Reportes automatizados básicos',
      'SLA 99.5% uptime',
    ],
    idealFor: ['Startups', 'PYMES', 'Equipos pequeños'],
    notIncluded: [
      'Modelos de ML personalizados',
      'Integraciones avanzadas',
      'Soporte 24/7',
      'Account manager dedicado',
    ],
    setupFee: 5000,
    annualDiscount: '20%',
  },
  
  business: {
    name: 'Business',
    price: 7500,
    currency: 'USD',
    period: 'mes',
    description: 'Para empresas en crecimiento con necesidades avanzadas de análisis',
    features: [
      'Dashboards ilimitados',
      'Hasta 5 fuentes de datos',
      'Hasta 25 usuarios',
      '1 modelo de ML incluido',
      'Integraciones estándar (CRM, ERP)',
      'Soporte telefónico',
      'Reportes automatizados avanzados',
      'API access',
      'SLA 99.9% uptime',
      'Capacitación inicial incluida',
    ],
    idealFor: ['Empresas medianas', 'Franquicias', 'Divisiones corporativas'],
    notIncluded: [
      'Modelos de ML ilimitados',
      'Soporte 24/7 prioritario',
      'Desarrollos custom',
    ],
    setupFee: 15000,
    annualDiscount: '25%',
  },
  
  enterprise: {
    name: 'Enterprise',
    price: 'Personalizado',
    currency: 'USD',
    period: 'mes',
    description: 'Solución completa para grandes corporaciones con requerimientos específicos',
    features: [
      'Todo lo del plan Business',
      'Modelos de ML ilimitados',
      'Fuentes de datos ilimitadas',
      'Usuarios ilimitados',
      'Integraciones custom',
      'Soporte 24/7 prioritario',
      'Account manager dedicado',
      'Desarrollos a medida',
      'On-premise opcional',
      'SLA 99.99% uptime',
      'Capacitación continua',
      'Auditorías de seguridad',
    ],
    idealFor: ['Corporaciones', 'Instituciones financieras', 'Gobierno', 'Salud'],
    startingAt: 20000,
    setupFee: 'Según alcance',
    annualDiscount: '30%',
  },
};

// ==========================================
// SERVICIOS INDIVIDUALES (PROYECTOS)
// ==========================================
const PROJECT_SERVICES = {
  dataAnalysis: {
    name: 'Análisis de Datos',
    description: 'Dashboards, KPIs y reportes personalizados',
    pricingTiers: [
      {
        tier: 'Básico',
        range: '$15,000 - $30,000',
        description: 'Hasta 5 dashboards, 1 fuente de datos',
        timeline: '2-4 semanas',
      },
      {
        tier: 'Avanzado',
        range: '$30,000 - $75,000',
        description: 'Hasta 15 dashboards, 3 fuentes de datos, ETL incluido',
        timeline: '4-8 semanas',
      },
      {
        tier: 'Enterprise',
        range: '$75,000 - $150,000+',
        description: 'Dashboards ilimitados, fuentes ilimitadas, arquitectura data lake',
        timeline: '8-16 semanas',
      },
    ],
    factors: [
      'Número de dashboards requeridos',
      'Volumen y complejidad de datos',
      'Número de fuentes de datos',
      'Frecuencia de actualización',
      'Necesidades de ETL/integración',
    ],
  },
  
  machineLearning: {
    name: 'Inteligencia Artificial / Machine Learning',
    description: 'Modelos predictivos, NLP, visión por computadora',
    pricingTiers: [
      {
        tier: 'Básico',
        range: '$25,000 - $50,000',
        description: '1 modelo de ML, dataset estándar, precisión >85%',
        timeline: '4-6 semanas',
      },
      {
        tier: 'Avanzado',
        range: '$50,000 - $120,000',
        description: 'Hasta 3 modelos, datasets complejos, precisión >90%, API incluida',
        timeline: '6-12 semanas',
      },
      {
        tier: 'Enterprise',
        range: '$120,000 - $300,000+',
        description: 'Modelos ilimitados, MLOps, auto-ML, precisión >95%',
        timeline: '12-24 semanas',
      },
    ],
    factors: [
      'Tipo de modelo (clasificación, regresión, NLP, visión)',
      'Volumen y calidad de datos de entrenamiento',
      'Nivel de precisión requerido',
      'Complejidad del problema',
      'Requerimientos de latencia',
      'Necesidades de explicabilidad',
    ],
  },
  
  predictiveConsulting: {
    name: 'Consultoría Predictiva',
    description: 'Forecasting, análisis de riesgos, optimización',
    pricingTiers: [
      {
        tier: 'Básico',
        range: '$20,000 - $40,000',
        description: '1 área de negocio, forecasting 3 meses, reporte mensual',
        timeline: '3-5 semanas',
      },
      {
        tier: 'Avanzado',
        range: '$40,000 - $90,000',
        description: '3 áreas de negocio, forecasting 12 meses, dashboard en tiempo real',
        timeline: '5-10 semanas',
      },
      {
        tier: 'Enterprise',
        range: '$90,000 - $200,000+',
        description: 'Toda la organización, múltiples escenarios, simulaciones, optimización continua',
        timeline: '10-20 semanas',
      },
    ],
    factors: [
      'Alcance del análisis (áreas de negocio)',
      'Horizonte de predicción',
      'Frecuencia de actualización',
      'Número de variables a considerar',
      'Necesidades de simulación',
    ],
  },
  
  dataEngineering: {
    name: 'Ingeniería de Datos',
    description: 'Data lakes, warehouses, pipelines ETL',
    pricingTiers: [
      {
        tier: 'Básico',
        range: '$30,000 - $60,000',
        description: 'Pipeline ETL, 2-3 fuentes, data warehouse básico',
        timeline: '4-6 semanas',
      },
      {
        tier: 'Avanzado',
        range: '$60,000 - $150,000',
        description: 'Data lake, 5-10 fuentes, ETL/ELT, gobernanza básica',
        timeline: '6-12 semanas',
      },
      {
        tier: 'Enterprise',
        range: '$150,000 - $400,000+',
        description: 'Arquitectura completa, fuentes ilimitadas, gobernanza avanzada, seguridad enterprise',
        timeline: '12-24 semanas',
      },
    ],
  },
};

// ==========================================
// SERVICIOS ADICIONALES
// ==========================================
const ADD_ONS = {
  additionalDashboard: {
    name: 'Dashboard adicional',
    price: 1500,
    unit: 'por dashboard',
  },
  additionalUser: {
    name: 'Usuario adicional',
    price: 50,
    unit: 'por usuario/mes',
  },
  additionalDataSource: {
    name: 'Fuente de datos adicional',
    price: 500,
    unit: 'por fuente/mes',
  },
  customIntegration: {
    name: 'Integración custom',
    price: '5000 - 25000',
    unit: 'por integración',
  },
  prioritySupport: {
    name: 'Soporte prioritario 24/7',
    price: 2000,
    unit: 'por mes',
  },
  trainingSession: {
    name: 'Sesión de capacitación',
    price: 1500,
    unit: 'por sesión (2h)',
  },
  dedicatedAccountManager: {
    name: 'Account manager dedicado',
    price: 3000,
    unit: 'por mes',
  },
};

// ==========================================
// FACTORES QUE AFECTAN EL PRECIO
// ==========================================
const PRICING_FACTORS = {
  dataVolume: {
    factor: 'Volumen de datos',
    impact: 'Mayor volumen = mayor infraestructura',
    ranges: [
      { range: '< 1GB', multiplier: 1.0 },
      { range: '1GB - 100GB', multiplier: 1.2 },
      { range: '100GB - 1TB', multiplier: 1.5 },
      { range: '1TB - 10TB', multiplier: 2.0 },
      { range: '> 10TB', multiplier: 'Custom' },
    ],
  },
  users: {
    factor: 'Número de usuarios',
    impact: 'Más usuarios = más licencias',
    ranges: [
      { range: '1-5', multiplier: 1.0 },
      { range: '6-25', multiplier: 1.3 },
      { range: '26-100', multiplier: 1.8 },
      { range: '> 100', multiplier: 'Custom' },
    ],
  },
  complexity: {
    factor: 'Complejidad del proyecto',
    impact: 'Mayor complejidad = más horas de desarrollo',
    ranges: [
      { range: 'Baja', multiplier: 1.0 },
      { range: 'Media', multiplier: 1.5 },
      { range: 'Alta', multiplier: 2.0 },
      { range: 'Muy alta', multiplier: 3.0 },
    ],
  },
  timeline: {
    factor: 'Urgencia/Timeline',
    impact: 'Entregas urgentes tienen costo adicional',
    ranges: [
      { range: 'Estándar', multiplier: 1.0 },
      { range: 'Rápido (50% más rápido)', multiplier: 1.3 },
      { range: 'Urgente (100% más rápido)', multiplier: 1.6 },
    ],
  },
};

// ==========================================
// RESPUESTAS TEMPLATE PARA EL CHATBOT
// ==========================================
const PRICING_RESPONSES = {
  general: `
💰 PLANES DE NEXORA ANALYTICS & AI

📊 Plan Starter: $2,500 USD/mes
• Ideal para startups y PYMES
• Hasta 3 dashboards, 1 fuente de datos
• Hasta 5 usuarios
• Cuota de implementación: $5,000 USD

🏢 Plan Business: $7,500 USD/mes
• Para empresas en crecimiento
• Dashboards ilimitados, hasta 5 fuentes
• Hasta 25 usuarios, 1 modelo ML incluido
• Cuota de implementación: $15,000 USD

🏭 Plan Enterprise: Desde $20,000 USD/mes
• Para grandes corporaciones
• Todo ilimitado + desarrollos custom
• Soporte 24/7 + account manager
• Cuota según alcance del proyecto

🎁 Descuentos: 20-30% por pago anual

¿Te gustaría que prepare una cotización personalizada para tu empresa?
`,

  projectBased: `
📋 COTIZACIÓN POR PROYECTO

Nuestros proyectos se cotizan según el servicio:

📊 Análisis de Datos: $15,000 - $150,000+
• Básico: $15k-$30k (2-4 semanas)
• Avanzado: $30k-$75k (4-8 semanas)
• Enterprise: $75k-$150k+ (8-16 semanas)

🤖 Inteligencia Artificial: $25,000 - $300,000+
• Básico: $25k-$50k (4-6 semanas)
• Avanzado: $50k-$120k (6-12 semanas)
• Enterprise: $120k-$300k+ (12-24 semanas)

📈 Consultoría Predictiva: $20,000 - $200,000+
• Básico: $20k-$40k (3-5 semanas)
• Avanzado: $40k-$90k (5-10 semanas)
• Enterprise: $90k-$200k+ (10-20 semanas)

El precio exacto depende de: volumen de datos, complejidad, usuarios y timeline.

¿Podrías contarme más sobre tu proyecto para darte una estimación más precisa?
`,

  customQuote: `
Para preparar una cotización personalizada necesito entender mejor tus necesidades:

1️⃣ ¿Qué servicio te interesa? (Análisis de Datos, IA, Consultoría)
2️⃣ ¿En qué industria trabajas?
3️⃣ ¿Cuál es el tamaño aproximado de tu empresa?
4️⃣ ¿Tienes datos disponibles? ¿En qué formato?
5️⃣ ¿Cuál es tu objetivo principal?
6️⃣ ¿Tienes algún presupuesto estimado?

Con esta información puedo preparar una propuesta detallada en 24-48 horas.
`,
};

// ==========================================
// EXPORTAR DATOS
// ==========================================
module.exports = {
  MONTHLY_PLANS,
  PROJECT_SERVICES,
  ADD_ONS,
  PRICING_FACTORS,
  PRICING_RESPONSES,
  
  // Helper para obtener respuesta según contexto
  getPricingResponse: (context = 'general') => {
    return PRICING_RESPONSES[context] || PRICING_RESPONSES.general;
  },
  
  // Helper para calcular estimado de proyecto
  estimateProject: (service, tier, factors = {}) => {
    const serviceData = PROJECT_SERVICES[service];
    if (!serviceData) return null;
    
    const tierData = serviceData.pricingTiers.find(t => t.tier.toLowerCase() === tier.toLowerCase());
    if (!tierData) return null;
    
    return {
      service: serviceData.name,
      tier: tierData.tier,
      estimatedRange: tierData.range,
      timeline: tierData.timeline,
      description: tierData.description,
      factors: serviceData.factors,
    };
  },
};
