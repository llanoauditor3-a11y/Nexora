/**
 * ==========================================
 * CHATBOT WIDGET COMPONENT
 * ==========================================
 * 
 * Características:
 * - Botón circular fijo en esquina inferior derecha
 * - Ventana desplegable con animación
 * - Mensajes simulados interactivos
 * - Input funcional con respuesta automática
 * - Diseño moderno tipo chat
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Minimize2 } from 'lucide-react';

// Interface para mensajes
interface Message {
  id: number;
  type: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

// Respuestas predefinidas del bot con información de cotizaciones
const botResponses: Record<string, string> = {
  'hola': '¡Hola! Bienvenido a Nexora Analytics & AI. Soy tu asistente virtual y puedo ayudarte con información sobre nuestros servicios, precios o agendar una reunión. ¿En qué puedo ayudarte hoy?',
  'buenos dias': '¡Buenos días! ¿Cómo puedo asistirte con nuestros servicios de IA y análisis de datos?',
  'buenas tardes': '¡Buenas tardes! Estoy aquí para resolver tus dudas sobre análisis de datos, IA y cotizaciones.',
  'buenas noches': '¡Buenas noches! Nuestro chatbot está disponible 24/7 para atenderte.',
  
  // Servicios
  'servicios': `Ofrecemos tres servicios principales:

📊 **Análisis de Datos**: Dashboards en tiempo real, KPIs personalizados, reportes automatizados.
💰 Desde $15,000 USD

🤖 **Inteligencia Artificial**: Machine Learning, NLP, visión por computadora, modelos predictivos.
💰 Desde $25,000 USD

📈 **Consultoría Predictiva**: Forecasting, análisis de riesgos, optimización de recursos.
💰 Desde $20,000 USD

¿Cuál te interesa? Puedo darte más detalles sobre precios.`,

  // Precios y planes
  'precio': `💰 **NUESTROS PLANES**:

📊 **Starter**: $2,500/mes
• 3 dashboards, 1 fuente de datos, 5 usuarios
• Implementación: $5,000 USD

🏢 **Business**: $7,500/mes  
• Dashboards ilimitados, 5 fuentes, 25 usuarios
• 1 modelo ML incluido
• Implementación: $15,000 USD

🏭 **Enterprise**: Desde $20,000/mes
• Todo ilimitado + desarrollos custom
• Soporte 24/7 + account manager

🎁 **Descuento anual**: 20-30%

¿Te gustaría una cotización personalizada?`,

  'cotizar': `Para preparar una cotización personalizada necesito saber:

1️⃣ ¿Qué servicio te interesa? (Análisis de Datos, IA, Consultoría)
2️⃣ ¿En qué industria trabajas?
3️⃣ ¿Cuál es el tamaño de tu empresa?
4️⃣ ¿Tienes datos disponibles?

Con esta información puedo darte un estimado en minutos.`,

  'cotizacion': `Para preparar una cotización personalizada necesito saber:

1️⃣ ¿Qué servicio te interesa? (Análisis de Datos, IA, Consultoría)
2️⃣ ¿En qué industria trabajas?
3️⃣ ¿Cuál es el tamaño de tu empresa?
4️⃣ ¿Tienes datos disponibles?

Con esta información puedo darte un estimado en minutos.`,

  'planes': `💰 **NUESTROS PLANES MENSUALES**:

📊 **Starter**: $2,500/mes
• Para startups y PYMES
• 3 dashboards, 1 fuente, 5 usuarios

🏢 **Business**: $7,500/mes
• Para empresas en crecimiento
• Dashboards ilimitados, 5 fuentes, 25 usuarios
• 1 modelo ML incluido

🏭 **Enterprise**: Desde $20,000/mes
• Para grandes corporaciones
• Todo ilimitado + desarrollos custom
• Soporte 24/7 + account manager

🎁 Descuento del 20-30% por pago anual

¿Te gustaría que prepare una cotización personalizada?`,

  // Servicios específicos
  'analisis': `📊 **ANÁLISIS DE DATOS - COTIZACIÓN**:

• **Básico**: $15,000 - $30,000 USD
  Hasta 5 dashboards, 1 fuente de datos
  
• **Avanzado**: $30,000 - $75,000 USD
  Hasta 15 dashboards, 3 fuentes, ETL incluido
  
• **Enterprise**: $75,000 - $150,000+ USD
  Dashboards ilimitados, arquitectura data lake

El precio exacto depende del volumen de datos y complejidad.

¿Te gustaría una estimación más precisa?`,

  'dashboard': `📊 **DASHBOARDS - COTIZACIÓN**:

Incluidos en nuestros planes mensuales:
• Plan Starter: 3 dashboards - $2,500/mes
• Plan Business: Ilimitados - $7,500/mes

Para proyectos individuales:
• Dashboard básico: $1,500 - $3,000 USD
• Dashboard avanzado: $3,000 - $8,000 USD
• Dashboard enterprise: $8,000+ USD

¿Te gustaría ver una demo de nuestros dashboards?`,

  'ia': `🤖 **INTELIGENCIA ARTIFICIAL - COTIZACIÓN**:

• **Básico**: $25,000 - $50,000 USD
  1 modelo de ML, dataset estándar, precisión >85%
  
• **Avanzado**: $50,000 - $120,000 USD
  Hasta 3 modelos, datasets complejos, precisión >90%
  
• **Enterprise**: $120,000 - $300,000+ USD
  Modelos ilimitados, MLOps, auto-ML, precisión >95%

Factores que afectan el precio: tipo de modelo, volumen de datos, precisión requerida.

¿Qué tipo de problema quieres resolver con IA?`,

  'machine learning': `🤖 **MACHINE LEARNING - COTIZACIÓN**:

• **Básico**: $25,000 - $50,000 USD
  1 modelo, dataset estándar, precisión >85%
  
• **Avanzado**: $50,000 - $120,000 USD
  Hasta 3 modelos, datasets complejos, precisión >90%
  
• **Enterprise**: $120,000 - $300,000+ USD
  Modelos ilimitados, MLOps, auto-ML

¿Qué tipo de modelo necesitas? (clasificación, predicción, NLP, visión)`,

  'consultoria': `📈 **CONSULTORÍA PREDICTIVA - COTIZACIÓN**:

• **Básico**: $20,000 - $40,000 USD
  1 área de negocio, forecasting 3 meses
  
• **Avanzado**: $40,000 - $90,000 USD
  3 áreas de negocio, forecasting 12 meses, dashboard
  
• **Enterprise**: $90,000 - $200,000+ USD
  Toda la organización, múltiples escenarios, optimización continua

¿En qué área de tu negocio necesitas forecasting?`,

  'predictiva': `📈 **CONSULTORÍA PREDICTIVA - COTIZACIÓN**:

• **Básico**: $20,000 - $40,000 USD
  1 área de negocio, forecasting 3 meses
  
• **Avanzado**: $40,000 - $90,000 USD
  3 áreas de negocio, forecasting 12 meses, dashboard
  
• **Enterprise**: $90,000 - $200,000+ USD
  Toda la organización, múltiples escenarios, optimización continua

¿En qué área de tu negocio necesitas forecasting?`,

  // Planes específicos
  'starter': `📊 **PLAN STARTER - $2,500/mes**:

✅ Incluye:
• Hasta 3 dashboards personalizados
• 1 fuente de datos
• Hasta 5 usuarios
• Soporte vía chat y email
• Reportes automatizados básicos

💵 Implementación: $5,000 USD (única vez)
🎁 Descuento anual: 20%

Ideal para: Startups, PYMES, equipos pequeños

¿Te gustaría agendar una demo?`,

  'business': `🏢 **PLAN BUSINESS - $7,500/mes**:

✅ Incluye:
• Dashboards ilimitados
• Hasta 5 fuentes de datos
• Hasta 25 usuarios
• 1 modelo de ML incluido
• Integraciones estándar (CRM, ERP)
• API access
• Soporte telefónico

💵 Implementación: $15,000 USD (única vez)
🎁 Descuento anual: 25%

Ideal para: Empresas medianas, franquicias

¿Te gustaría agendar una demo?`,

  'enterprise': `🏭 **PLAN ENTERPRISE - Desde $20,000/mes**:

✅ Incluye TODO lo del plan Business, más:
• Modelos de ML ilimitados
• Fuentes de datos ilimitadas
• Usuarios ilimitados
• Integraciones custom
• Soporte 24/7 prioritario
• Account manager dedicado
• Desarrollos a medida
• On-premise opcional

💵 Implementación: Según alcance
🎁 Descuento anual: 30%

Ideal para: Corporaciones, instituciones financieras, gobierno

¿Te gustaría hablar con un especialista?`,

  // Contacto y demo
  'contacto': `📞 **CONTACTO NEXORA**:

📱 WhatsApp: +52 55 1234 5678
📧 Email: hola@nexora.ai
🌐 Web: www.nexora.ai

⏰ Horario de atención:
Lunes a Viernes: 9:00 - 18:00 (CDMX)

💬 Chatbot disponible 24/7

¿Te gustaría que agende una llamada con nuestro equipo?`,

  'whatsapp': '📱 Nuestro WhatsApp es **+52 55 1234 5678**. ¡Escríbenos cuando quieras! También puedo agendarte una llamada si lo prefieres.',

  'demo': `🎯 **DEMO GRATUITA**:

¡Claro! Puedo agendarte una demostración personalizada de 30 minutos donde verás:

📊 Dashboards en tiempo real
🤖 Modelos de ML funcionando
📈 Casos de éxito de tu industria

Horarios disponibles:
• Lunes a Viernes: 9:00 - 18:00 (CDMX)
• Modalidad: Zoom o Google Meet

¿Qué día y horario te funciona mejor?`,

  'reunion': `🎯 **REUNIÓN CON NUESTRO EQUIPO**:

¡Perfecto! Puedo agendarte una reunión de 30 minutos con nuestros especialistas.

Horarios disponibles:
• Lunes a Viernes: 9:00 - 18:00 (CDMX)
• Modalidad: Zoom o Google Meet

Para confirmar necesito:
1️⃣ Tu nombre
2️⃣ Tu correo electrónico
3️⃣ Tu empresa
4️⃣ Día y horario preferido

¿Te parece bien?`,

  // Despedida
  'gracias': '¡De nada! Estoy aquí para lo que necesites. ¿Hay algo más en lo que pueda ayudarte? Puedo darte información sobre precios, servicios o agendar una reunión.',
  
  'adios': '¡Hasta luego! No dudes en volver si tienes más preguntas sobre nuestros servicios o precios. ¡Que tengas un excelente día! 🚀',

  // Default
  'default': `Entiendo. Puedo ayudarte con:

📊 Información sobre nuestros servicios
💰 Cotizaciones y planes de precios
📅 Agendar una demo o reunión

¿Qué te gustaría saber?`,
};

const ChatbotWidget = () => {
  // Estados
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: 'bot',
      text: '¡Hola! ¿Cómo puedo ayudarte hoy?',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [hasNewMessage, setHasNewMessage] = useState(false);
  
  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll al último mensaje
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus en input cuando se abre
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen]);

  // Indicador de mensaje nuevo cuando está cerrado
  useEffect(() => {
    if (!isOpen && messages.length > 1) {
      setHasNewMessage(true);
    }
  }, [messages, isOpen]);

  // Reset indicador al abrir
  useEffect(() => {
    if (isOpen) {
      setHasNewMessage(false);
    }
  }, [isOpen]);

  // Función para obtener respuesta del bot
  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase().trim();
    
    // Buscar palabras clave
    for (const [keyword, response] of Object.entries(botResponses)) {
      if (lowerMessage.includes(keyword)) {
        return response;
      }
    }
    
    return botResponses.default;
  };

  // Función para enviar mensaje
  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userText = inputValue.trim();
    
    // Agregar mensaje del usuario
    const userMessage: Message = {
      id: messages.length + 1,
      type: 'user',
      text: userText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simular respuesta del bot
    setTimeout(() => {
      const botResponse = getBotResponse(userText);
      
      const botMessage: Message = {
        id: messages.length + 2,
        type: 'bot',
        text: botResponse,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // Tiempo variable para naturalidad
  };

  // Manejar tecla Enter
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Formatear hora
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('es-ES', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <>
      {/* ==========================================
          CHAT WINDOW
          ========================================== */}
      <div
        className={`fixed bottom-24 right-4 sm:right-6 lg:right-8 z-50 w-[90vw] max-w-[380px] transition-all duration-500 ${
          isOpen
            ? 'opacity-100 translate-y-0 scale-100'
            : 'opacity-0 translate-y-8 scale-95 pointer-events-none'
        }`}
      >
        <div className="glass-card rounded-2xl overflow-hidden shadow-2xl shadow-black/50">
          
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-nexora-cyan/10 bg-nexora-dark-blue/80">
            <div className="flex items-center gap-3">
              {/* Avatar del bot */}
              <div className="relative">
                <div className="absolute inset-0 bg-nexora-cyan/30 rounded-full blur-md animate-pulse" />
                <div className="relative w-10 h-10 rounded-full bg-gradient-to-br from-nexora-cyan/30 to-nexora-cyan/10 border border-nexora-cyan/40 flex items-center justify-center">
                  <Bot className="w-5 h-5 text-nexora-cyan" />
                </div>
                {/* Indicador online */}
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-nexora-dark-blue" />
              </div>
              
              {/* Info */}
              <div>
                <span className="text-sm font-medium text-white block">Nexora Assistant</span>
                <span className="text-xs text-nexora-gray flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                  En línea ahora
                </span>
              </div>
            </div>
            
            {/* Botones de control */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 text-nexora-gray hover:text-nexora-cyan hover:bg-nexora-cyan/10 rounded-lg transition-all"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setIsOpen(false);
                  setMessages([{
                    id: 1,
                    type: 'bot',
                    text: '¡Hola! ¿Cómo puedo ayudarte hoy?',
                    timestamp: new Date(),
                  }]);
                }}
                className="p-2 text-nexora-gray hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="h-80 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-nexora-midnight/80 to-nexora-dark-blue/50">
            {/* Mensaje de bienvenida con info */}
            <div className="bg-nexora-cyan/5 border border-nexora-cyan/10 rounded-xl p-3 mb-4">
              <p className="text-xs text-nexora-gray text-center">
                Este es un chatbot de demostración. Pregúntame sobre servicios, precios o contacto.
              </p>
            </div>

            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-2 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}
              >
                {/* Avatar */}
                <div
                  className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${
                    message.type === 'user'
                      ? 'bg-nexora-cyan/20'
                      : 'bg-nexora-dark-blue border border-nexora-cyan/30'
                  }`}
                >
                  {message.type === 'user' ? (
                    <User className="w-3.5 h-3.5 text-nexora-cyan" />
                  ) : (
                    <Bot className="w-3.5 h-3.5 text-nexora-cyan" />
                  )}
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-[75%] px-3 py-2 text-sm ${
                    message.type === 'user'
                      ? 'chat-bubble-user text-white rounded-2xl rounded-tr-sm'
                      : 'chat-bubble-bot text-nexora-gray-light rounded-2xl rounded-tl-sm'
                  }`}
                >
                  <p>{message.text}</p>
                  <span className="text-[10px] text-nexora-gray/60 mt-1 block">
                    {formatTime(message.timestamp)}
                  </span>
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-2">
                <div className="flex-shrink-0 w-7 h-7 rounded-full bg-nexora-dark-blue border border-nexora-cyan/30 flex items-center justify-center">
                  <Bot className="w-3.5 h-3.5 text-nexora-cyan" />
                </div>
                <div className="chat-bubble-bot px-4 py-3 flex items-center gap-1 rounded-2xl rounded-tl-sm">
                  <span
                    className="w-2 h-2 rounded-full bg-nexora-cyan/50 animate-bounce"
                    style={{ animationDelay: '0ms' }}
                  />
                  <span
                    className="w-2 h-2 rounded-full bg-nexora-cyan/50 animate-bounce"
                    style={{ animationDelay: '150ms' }}
                  />
                  <span
                    className="w-2 h-2 rounded-full bg-nexora-cyan/50 animate-bounce"
                    style={{ animationDelay: '300ms' }}
                  />
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 border-t border-nexora-cyan/10 bg-nexora-dark-blue/80">
            <div className="flex gap-2">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Escribe un mensaje..."
                className="flex-1 px-4 py-2.5 text-sm text-white bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-xl focus:outline-none focus:border-nexora-cyan/50 focus:ring-1 focus:ring-nexora-cyan/30 placeholder:text-nexora-gray/50 transition-all"
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputValue.trim()}
                className="px-4 py-2.5 bg-gradient-to-r from-nexora-cyan to-nexora-cyan-dark text-nexora-midnight rounded-xl hover:shadow-neon transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ==========================================
          FLOATING BUTTON
          ========================================== */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-4 sm:right-6 lg:right-8 z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-500 ${
          isOpen
            ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
            : 'bg-gradient-to-r from-nexora-cyan to-nexora-cyan-dark text-nexora-midnight hover:shadow-neon-strong animate-pulse-glow'
        }`}
        aria-label={isOpen ? 'Cerrar chat' : 'Abrir chat'}
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
        
        {/* Notification Badge */}
        {!isOpen && hasNewMessage && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-bold text-white animate-bounce">
            1
          </span>
        )}
      </button>
    </>
  );
};

export default ChatbotWidget;
