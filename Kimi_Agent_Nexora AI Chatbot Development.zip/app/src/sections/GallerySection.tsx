/**
 * ==========================================
 * GALLERY SECTION COMPONENT
 * ==========================================
 * 
 * Características:
 * - Tres imágenes en grid responsive
 * - Efecto hover zoom suave
 * - Overlay con información
 * - Títulos descriptivos
 * - Animaciones de entrada
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useEffect, useRef, useState } from 'react';
import { ExternalLink } from 'lucide-react';

// Interface para items de la galería
interface GalleryItem {
  id: number;
  image: string;
  title: string;
  description: string;
}

const GallerySection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  // Detectar cuando la sección está visible
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Datos de la galería
  const galleryItems: GalleryItem[] = [
    {
      id: 1,
      image: '/images/gallery-datacenter.jpg',
      title: 'Centros de Datos Futuristas',
      description: 'Infraestructura de última generación para procesamiento masivo de datos',
    },
    {
      id: 2,
      image: '/images/gallery-analytics.jpg',
      title: 'Análisis Avanzado en IA',
      description: 'Visualizaciones inteligentes que revelan insights ocultos',
    },
    {
      id: 3,
      image: '/images/gallery-smartcity.jpg',
      title: 'Ciudades Inteligentes',
      description: 'Conectando el mundo mediante IoT y análisis predictivo',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* ==========================================
          BACKGROUND ELEMENTS
          ========================================== */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B1120] via-[#0F172A] to-[#0B1120]" />
      
      {/* Línea divisoria superior */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-nexora-cyan/30 to-transparent" />

      {/* ==========================================
          CONTENT
          ========================================== */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        
        {/* ==========================================
            SECTION HEADER
            ========================================== */}
        <div className={`text-center mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="section-title font-orbitron text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Nuestra Tecnología
          </h2>
          <p className="text-nexora-gray max-w-2xl mx-auto mt-4">
            Explora el futuro de la inteligencia artificial y el análisis de datos
          </p>
        </div>

        {/* ==========================================
            GALLERY GRID
            ========================================== */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 max-w-7xl mx-auto">
          {galleryItems.map((item, index) => (
            <GalleryCard
              key={item.id}
              item={item}
              index={index}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>

      {/* Línea divisoria inferior */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-nexora-cyan/30 to-transparent" />
    </section>
  );
};

// Componente individual para cada tarjeta de galería
interface GalleryCardProps {
  item: GalleryItem;
  index: number;
  isVisible: boolean;
}

const GalleryCard = ({ item, index, isVisible }: GalleryCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`group relative transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${index * 150}ms` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Contenedor de la imagen */}
      <div className="relative aspect-[4/3] rounded-2xl overflow-hidden img-zoom">
        
        {/* Imagen */}
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-full object-cover"
        />

        {/* Overlay gradiente */}
        <div 
          className={`absolute inset-0 bg-gradient-to-t from-nexora-midnight via-nexora-midnight/50 to-transparent transition-opacity duration-500 ${
            isHovered ? 'opacity-90' : 'opacity-60'
          }`}
        />

        {/* Borde brillante en hover */}
        <div 
          className={`absolute inset-0 border-2 rounded-2xl transition-all duration-500 ${
            isHovered 
              ? 'border-nexora-cyan/50 shadow-neon' 
              : 'border-nexora-cyan/0'
          }`}
        />

        {/* Contenido */}
        <div className="absolute inset-0 p-6 flex flex-col justify-end">
          {/* Título */}
          <h3 
            className={`font-orbitron text-lg lg:text-xl font-bold text-white mb-2 transition-all duration-500 ${
              isHovered ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-90'
            }`}
          >
            {item.title}
          </h3>

          {/* Descripción - aparece en hover */}
          <p 
            className={`text-sm text-nexora-gray-light transition-all duration-500 ${
              isHovered 
                ? 'opacity-100 translate-y-0 max-h-20' 
                : 'opacity-0 translate-y-4 max-h-0'
            } overflow-hidden`}
          >
            {item.description}
          </p>

          {/* Botón - aparece en hover */}
          <div 
            className={`mt-4 transition-all duration-500 ${
              isHovered 
                ? 'opacity-100 translate-y-0' 
                : 'opacity-0 translate-y-4'
            }`}
          >
            <button className="flex items-center gap-2 text-nexora-cyan text-sm font-medium group/btn">
              <span className="relative">
                Ver más
                <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-nexora-cyan transition-all duration-300 group-hover/btn:w-full" />
              </span>
              <ExternalLink className="w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
            </button>
          </div>
        </div>

        {/* Esquinas decorativas */}
        <div 
          className={`absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-nexora-cyan/50 rounded-tl-lg transition-all duration-500 ${
            isHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
          }`}
        />
        <div 
          className={`absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-nexora-cyan/50 rounded-br-lg transition-all duration-500 ${
            isHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
          }`}
        />
      </div>
    </div>
  );
};

export default GallerySection;
