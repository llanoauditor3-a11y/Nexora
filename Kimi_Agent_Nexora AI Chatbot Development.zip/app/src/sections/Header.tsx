/**
 * ==========================================
 * HEADER COMPONENT - Navegación Fija
 * ==========================================
 * 
 * Características:
 * - Logo animado con efecto de brillo
 * - Navegación responsive con menú móvil
 * - Efecto de fondo al hacer scroll
 * - Botón CTA con glow neón
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useState, useEffect } from 'react';
import { Menu, X, Brain, ChevronDown } from 'lucide-react';

const Header = () => {
  // Estado para controlar la visibilidad del menú móvil
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Estado para detectar scroll y aplicar efecto de fondo
  const [isScrolled, setIsScrolled] = useState(false);

  // Efecto para detectar scroll
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Items de navegación
  const navItems = [
    { label: 'Servicios', href: '#servicios', hasDropdown: true },
    { label: 'Experiencia', href: '#experiencia', hasDropdown: true },
    { label: 'FAQ', href: '#faq', hasDropdown: false },
    { label: 'Contacto', href: '#contacto', hasDropdown: false },
  ];

  // Función para scroll suave a secciones
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-[#0B1120]/90 backdrop-blur-xl shadow-lg shadow-black/20'
          : 'bg-transparent'
      }`}
    >
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* ==========================================
              LOGO SECTION
              ========================================== */}
          <a 
            href="#" 
            className="flex items-center gap-3 group"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          >
            {/* Icono del cerebro con animación de pulso */}
            <div className="relative">
              <div className="absolute inset-0 bg-nexora-cyan/30 rounded-full blur-lg animate-pulse-glow" />
              <Brain className="w-8 h-8 lg:w-10 lg:h-10 text-nexora-cyan relative z-10 transition-transform duration-300 group-hover:scale-110" />
            </div>
            
            {/* Texto del logo */}
            <div className="flex flex-col">
              <span className="font-orbitron font-bold text-lg lg:text-xl text-white tracking-wider">
                NEXORA
              </span>
              <span className="text-[10px] lg:text-xs text-nexora-gray tracking-[0.2em] uppercase">
                Analytics & AI
              </span>
            </div>
          </a>

          {/* ==========================================
              DESKTOP NAVIGATION
              ========================================== */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(item.href);
                }}
                className="flex items-center gap-1 text-sm text-nexora-gray hover:text-nexora-cyan transition-colors duration-300 group"
              >
                <span className="relative">
                  {item.label}
                  {/* Línea decorativa debajo del texto */}
                  <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-gradient-to-r from-nexora-cyan to-transparent transition-all duration-300 group-hover:w-full" />
                </span>
                {item.hasDropdown && (
                  <ChevronDown className="w-4 h-4 transition-transform duration-300 group-hover:rotate-180" />
                )}
              </a>
            ))}
          </nav>

          {/* ==========================================
              CTA BUTTON - Consulta IA Gratis
              ========================================== */}
          <div className="hidden lg:block">
            <button 
              onClick={() => scrollToSection('#contacto')}
              className="neon-button px-6 py-2.5 rounded-lg text-sm font-medium"
            >
              Consulta IA Gratis
            </button>
          </div>

          {/* ==========================================
              MOBILE MENU BUTTON
              ========================================== */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 text-nexora-gray hover:text-nexora-cyan transition-colors"
            aria-label={isMenuOpen ? 'Cerrar menú' : 'Abrir menú'}
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>

      {/* ==========================================
          MOBILE MENU OVERLAY
          ========================================== */}
      <div
        className={`lg:hidden fixed inset-0 top-16 bg-[#0B1120]/98 backdrop-blur-xl transition-all duration-500 ${
          isMenuOpen
            ? 'opacity-100 visible'
            : 'opacity-0 invisible'
        }`}
      >
        <nav className="flex flex-col items-center justify-center h-full gap-8">
          {navItems.map((item, index) => (
            <a
              key={item.label}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                scrollToSection(item.href);
              }}
              className="text-2xl font-orbitron text-white hover:text-nexora-cyan transition-colors duration-300"
              style={{
                animationDelay: `${index * 100}ms`,
              }}
            >
              {item.label}
            </a>
          ))}
          
          {/* CTA Button Mobile */}
          <button 
            onClick={() => scrollToSection('#contacto')}
            className="neon-button-primary mt-4 px-8 py-3 rounded-lg text-base font-medium"
          >
            Consulta IA Gratis
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
