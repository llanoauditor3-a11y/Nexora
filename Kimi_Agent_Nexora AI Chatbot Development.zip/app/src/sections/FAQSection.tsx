/**
 * ==========================================
 * FAQ SECTION COMPONENT
 * ==========================================
 * 
 * Sección de Preguntas Frecuentes con:
 * - Acordeón animado
 * - Búsqueda de preguntas
 * - Categorías organizadas
 * - Diseño glassmorphism
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, HelpCircle, MessageSquare } from 'lucide-react';

// Interface para items de FAQ
interface FAQItem {
  id: number;
  category: string;
  question: string;
  answer: string;
}

const FAQSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [openItem, setOpenItem] = useState<number | null>(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('todas');

  // Detectar cuando la sección está visible
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Datos de FAQ organizados por categorías
  const faqData: FAQItem[] = [
    // Categoría: Servicios
    {
      id: 1,
      category: 'servicios',
      question: '¿Qué servicios ofrece Nexora Analytics & AI?',
      answer: 'Ofrecemos tres servicios principales: (1) Análisis de Datos con dashboards avanzados y KPIs personalizados, (2) Inteligencia Artificial con machine learning, NLP y visión por computadora, y (3) Consultoría Predictiva con modelos de forecasting y análisis de riesgos. Todos nuestros servicios están diseñados para transformar tus datos en decisiones inteligentes.'
    },
    {
      id: 2,
      category: 'servicios',
      question: '¿Cómo funciona el proceso de implementación?',
      answer: 'Nuestro proceso consta de 5 fases: (1) Descubrimiento - analizamos tus necesidades y datos actuales, (2) Diseño - creamos la arquitectura de la solución, (3) Desarrollo - construimos los modelos y dashboards, (4) Implementación - integramos con tus sistemas, y (5) Soporte - proporcionamos mantenimiento y optimización continua. El tiempo promedio es de 4-8 semanas dependiendo de la complejidad.'
    },
    {
      id: 3,
      category: 'servicios',
      question: '¿Pueden integrarse con nuestros sistemas existentes?',
      answer: 'Sí, nuestras soluciones son altamente integrables. Trabajamos con APIs, conectores nativos y ETLs personalizados para integrarnos con: CRMs (Salesforce, HubSpot), ERPs (SAP, Oracle), bases de datos (SQL, NoSQL), plataformas cloud (AWS, Azure, GCP), y herramientas de BI existentes. Garantizamos una transición sin fricciones.'
    },

    // Categoría: Precios y Cotizaciones
    {
      id: 4,
      category: 'precios',
      question: '¿Cuáles son los planes de precios disponibles?',
      answer: 'Contamos con 3 planes: Starter ($2,500 USD/mes) ideal para startups y PYMES, Business ($7,500 USD/mes) para empresas en crecimiento con necesidades avanzadas, y Enterprise (personalizado) para grandes corporaciones con requerimientos específicos. Todos incluyen soporte, actualizaciones y capacitación. Ofrecemos descuentos por pago anual.'
    },
    {
      id: 5,
      category: 'precios',
      question: '¿Cómo funciona la cotización de proyectos personalizados?',
      answer: 'Para proyectos personalizados, evaluamos: (1) Volumen y complejidad de datos, (2) Número de usuarios y dashboards requeridos, (3) Integraciones necesarias, (4) Tiempo de implementación, y (5) Nivel de soporte. El costo típico de implementación inicial varía entre $15,000 y $150,000 USD. Agenda una consulta gratuita para recibir una cotización detallada en 24-48 horas.'
    },
    {
      id: 6,
      category: 'precios',
      question: '¿Hay costos ocultos o de implementación adicionales?',
      answer: 'No. Nuestras cotizaciones son transparentes y todo incluido. El precio cubre: desarrollo e implementación, capacitación del equipo, documentación, soporte durante 3 meses post-implementación, y garantía de funcionamiento. Los únicos costos adicionales serían por: integraciones con sistemas de terceros que requieran licencias, o solicitudes de cambio fuera del alcance inicial.'
    },
    {
      id: 7,
      category: 'precios',
      question: '¿Ofrecen garantía de resultados?',
      answer: 'Sí, garantizamos la satisfacción con nuestra política de: (1) 30 días de prueba con reembolso completo si no estás satisfecho, (2) SLA de disponibilidad del 99.9% para nuestras soluciones cloud, (3) Mejora continua - si los modelos no alcanzan los KPIs acordados, optimizamos sin costo adicional hasta lograrlos. Tu éxito es nuestra prioridad.'
    },

    // Categoría: Tecnología
    {
      id: 8,
      category: 'tecnologia',
      question: '¿Qué tecnologías y herramientas utilizan?',
      answer: 'Trabajamos con el stack tecnológico más avanzado: Python, TensorFlow, PyTorch para ML; OpenAI, Anthropic para LLMs; AWS, Azure, GCP para cloud; Tableau, PowerBI, Looker para visualización; SQL, PostgreSQL, MongoDB, Snowflake para datos; Docker, Kubernetes para deployment. Seleccionamos la mejor tecnología según tus necesidades específicas.'
    },
    {
      id: 9,
      category: 'tecnologia',
      question: '¿Dónde se almacenan mis datos? ¿Son seguros?',
      answer: 'La seguridad es primordial. Ofrecemos: (1) Alojamiento en la nube de tu elección (AWS, Azure, GCP) con certificaciones ISO 27001, SOC 2, (2) Encriptación en tránsito y en reposo (AES-256), (3) Cumplimiento GDPR, HIPAA según industria, (4) Acceso basado en roles (RBAC), (5) Auditorías de seguridad trimestrales, y (6) Opción de despliegue on-premise si lo requieres.'
    },
    {
      id: 10,
      category: 'tecnologia',
      question: '¿Cuál es el tiempo de respuesta de los dashboards?',
      answer: 'Nuestros dashboards están optimizados para rendimiento: datos en tiempo real se actualizan en menos de 2 segundos, reportes diarios se generan en menos de 30 segundos, y análisis complejos de grandes volúmenes (TB+) se completan en menos de 5 minutos. Implementamos caching inteligente y optimización de consultas para garantizar velocidad.'
    },

    // Categoría: Soporte
    {
      id: 11,
      category: 'soporte',
      question: '¿Qué tipo de soporte ofrecen?',
      answer: 'Todos los planes incluyen: soporte técnico vía chat y email con respuesta en menos de 4 horas, base de conocimiento y documentación completa, webinars mensuales de capacitación, y community forum. Planes Business y Enterprise adicionan: soporte telefónico 24/7, account manager dedicado, y visitas presenciales trimestrales.'
    },
    {
      id: 12,
      category: 'soporte',
      question: '¿Cuánto tiempo toma ver resultados?',
      answer: 'Los resultados varían según el servicio: Dashboards y visualizaciones muestran valor inmediato desde el día 1. Modelos de ML típicamente requieren 2-4 semanas de entrenamiento para alcanzar precisión óptima. Consultoría predictiva entrega insights accionables en la primera semana. Nuestros clientes reportan ROI positivo en promedio a los 3 meses de implementación.'
    },
    {
      id: 13,
      category: 'soporte',
      question: '¿Cómo empiezo a trabajar con Nexora?',
      answer: 'Es muy sencillo: (1) Agenda una consulta gratuita de 30 minutos con nuestro equipo, (2) Realizamos un análisis de tus datos y necesidades sin compromiso, (3) Recibes una propuesta detallada con alcance, tiempo y precio en 48 horas, (4) Firmamos acuerdo y comenzamos la implementación. El proceso de onboarding está diseñado para ser ágil y sin fricciones.'
    },
  ];

  // Categorías disponibles
  const categories = [
    { id: 'todas', label: 'Todas', icon: HelpCircle },
    { id: 'servicios', label: 'Servicios', icon: MessageSquare },
    { id: 'precios', label: 'Precios', icon: ChevronDown },
    { id: 'tecnologia', label: 'Tecnología', icon: ChevronDown },
    { id: 'soporte', label: 'Soporte', icon: ChevronDown },
  ];

  // Filtrar FAQ según búsqueda y categoría
  const filteredFAQ = faqData.filter(item => {
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'todas' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  // Toggle item
  const toggleItem = (id: number) => {
    setOpenItem(openItem === id ? null : id);
  };

  return (
    <section
      id="faq"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* ==========================================
          BACKGROUND ELEMENTS
          ========================================== */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B1120] via-[#0F172A] to-[#0B1120]" />
      
      {/* Línea divisoria superior */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-nexora-cyan/30 to-transparent" />
      
      {/* Círculos decorativos */}
      <div className="absolute top-1/4 -right-32 w-64 h-64 bg-nexora-cyan/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -left-32 w-64 h-64 bg-nexora-cyan/5 rounded-full blur-3xl" />

      {/* ==========================================
          CONTENT
          ========================================== */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        
        {/* ==========================================
            SECTION HEADER
            ========================================== */}
        <div className={`text-center mb-12 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
            <HelpCircle className="w-4 h-4 text-nexora-cyan" />
            <span className="text-sm text-nexora-gray">¿Tienes dudas?</span>
          </div>
          
          <h2 className="section-title font-orbitron text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Preguntas Frecuentes
          </h2>
          <p className="text-nexora-gray max-w-2xl mx-auto">
            Encuentra respuestas a las preguntas más comunes sobre nuestros servicios, precios y proceso de trabajo
          </p>
        </div>

        {/* ==========================================
            SEARCH BAR
            ========================================== */}
        <div className={`max-w-2xl mx-auto mb-8 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-nexora-gray" />
            <input
              type="text"
              placeholder="Buscar preguntas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-nexora-dark-blue/50 border border-nexora-cyan/20 rounded-xl text-white placeholder:text-nexora-gray/50 focus:outline-none focus:border-nexora-cyan/50 focus:ring-1 focus:ring-nexora-cyan/30 transition-all"
            />
          </div>
        </div>

        {/* ==========================================
            CATEGORY FILTERS
            ========================================== */}
        <div className={`flex flex-wrap justify-center gap-3 mb-10 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === cat.id
                  ? 'bg-nexora-cyan text-nexora-midnight'
                  : 'bg-nexora-dark-blue/50 text-nexora-gray border border-nexora-cyan/20 hover:border-nexora-cyan/50 hover:text-nexora-cyan'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* ==========================================
            FAQ ACCORDION
            ========================================== */}
        <div className={`max-w-3xl mx-auto space-y-4 transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {filteredFAQ.length > 0 ? (
            filteredFAQ.map((item, index) => (
              <div
                key={item.id}
                className="glass-card rounded-xl overflow-hidden transition-all duration-300 hover:border-nexora-cyan/30"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Question Header */}
                <button
                  onClick={() => toggleItem(item.id)}
                  className="w-full flex items-center justify-between p-5 text-left group"
                >
                  <span className="text-white font-medium pr-4 group-hover:text-nexora-cyan transition-colors">
                    {item.question}
                  </span>
                  <ChevronDown 
                    className={`w-5 h-5 text-nexora-cyan flex-shrink-0 transition-transform duration-300 ${
                      openItem === item.id ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {/* Answer Content */}
                <div 
                  className={`overflow-hidden transition-all duration-300 ${
                    openItem === item.id ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <div className="px-5 pb-5">
                    <div className="h-px bg-nexora-cyan/10 mb-4" />
                    <p className="text-nexora-gray leading-relaxed">
                      {item.answer}
                    </p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <HelpCircle className="w-12 h-12 text-nexora-gray/30 mx-auto mb-4" />
              <p className="text-nexora-gray">No se encontraron preguntas que coincidan con tu búsqueda</p>
              <button 
                onClick={() => {setSearchQuery(''); setActiveCategory('todas');}}
                className="mt-4 text-nexora-cyan hover:underline"
              >
                Ver todas las preguntas
              </button>
            </div>
          )}
        </div>

        {/* ==========================================
            CTA - MÁS PREGUNTAS
            ========================================== */}
        <div className={`text-center mt-12 transition-all duration-700 delay-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <p className="text-nexora-gray mb-4">¿No encontraste lo que buscabas?</p>
          <button 
            onClick={() => {
              const chatbotBtn = document.querySelector('[aria-label="Abrir chat"]') as HTMLButtonElement;
              chatbotBtn?.click();
            }}
            className="neon-button-primary px-6 py-3 rounded-xl text-sm font-medium inline-flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Hablar con nuestro asistente
          </button>
        </div>
      </div>

      {/* Línea divisoria inferior */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-nexora-cyan/30 to-transparent" />
    </section>
  );
};

export default FAQSection;
