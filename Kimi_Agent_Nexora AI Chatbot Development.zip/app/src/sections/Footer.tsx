/**
 * ==========================================
 * FOOTER COMPONENT
 * ==========================================
 * 
 * Características:
 * - Información de contacto completa
 * - Enlace directo a WhatsApp
 * - Diseño limpio minimalista
 * - Fondo oscuro con línea divisoria
 * - Links a redes sociales
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { 
  Brain, 
  Mail, 
  Phone, 
  MapPin, 
  MessageCircle,
  Linkedin,
  Twitter,
  Github,
  Instagram,
  ArrowUpRight
} from 'lucide-react';

const Footer = () => {
  // Datos de contacto
  const contactInfo = {
    email: 'hola@nexora.ai',
    phone: '+52 55 1234 5678',
    whatsapp: 'https://wa.me/525512345678',
    address: 'Ciudad de México, México',
  };

  // Links de navegación
  const navLinks = [
    { label: 'Servicios', href: '#servicios' },
    { label: 'Experiencia', href: '#experiencia' },
    { label: 'Tecnología', href: '#tecnologia' },
    { label: 'Contacto', href: '#contacto' },
  ];

  // Servicios
  const services = [
    'Análisis de Datos',
    'Inteligencia Artificial',
    'Consultoría Predictiva',
    'Machine Learning',
  ];

  // Redes sociales
  const socialLinks = [
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Instagram, href: '#', label: 'Instagram' },
  ];

  // Función para scroll suave
  const scrollToSection = (href: string) => {
    if (href === '#') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contacto" className="relative bg-[#0B1120] overflow-hidden">
      {/* ==========================================
          TOP DIVIDER LINE
          ========================================== */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-nexora-cyan/30 to-transparent" />

      {/* ==========================================
          MAIN FOOTER CONTENT
          ========================================== */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20 py-16 lg:py-20">
        <div className="max-w-7xl mx-auto">
          
          {/* Grid principal */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
            
            {/* ==========================================
                COLUMN 1: Logo & Description
                ========================================== */}
            <div className="lg:col-span-1">
              {/* Logo */}
              <a 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('#');
                }}
                className="flex items-center gap-3 mb-6 group"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-nexora-cyan/20 rounded-full blur-lg group-hover:blur-xl transition-all" />
                  <Brain className="w-8 h-8 text-nexora-cyan relative z-10" />
                </div>
                <div className="flex flex-col">
                  <span className="font-orbitron font-bold text-lg text-white tracking-wider">
                    NEXORA
                  </span>
                  <span className="text-[10px] text-nexora-gray tracking-[0.2em] uppercase">
                    Analytics & AI
                  </span>
                </div>
              </a>

              {/* Descripción */}
              <p className="text-nexora-gray text-sm leading-relaxed mb-6">
                Transformamos datos en decisiones inteligentes. 
                Soluciones de IA de próxima generación para impulsar tu negocio.
              </p>

              {/* Redes sociales */}
              <div className="flex gap-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 rounded-lg bg-nexora-dark-blue border border-nexora-cyan/10 flex items-center justify-center text-nexora-gray hover:text-nexora-cyan hover:border-nexora-cyan/30 hover:bg-nexora-cyan/5 transition-all"
                  >
                    <social.icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>

            {/* ==========================================
                COLUMN 2: Navigation Links
                ========================================== */}
            <div>
              <h4 className="font-orbitron text-sm font-semibold text-white mb-6 tracking-wider">
                NAVEGACIÓN
              </h4>
              <ul className="space-y-3">
                {navLinks.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        scrollToSection(link.href);
                      }}
                      className="text-nexora-gray text-sm hover:text-nexora-cyan transition-colors inline-flex items-center gap-1 group"
                    >
                      <span className="relative">
                        {link.label}
                        <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-nexora-cyan transition-all duration-300 group-hover:w-full" />
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* ==========================================
                COLUMN 3: Services
                ========================================== */}
            <div>
              <h4 className="font-orbitron text-sm font-semibold text-white mb-6 tracking-wider">
                SERVICIOS
              </h4>
              <ul className="space-y-3">
                {services.map((service) => (
                  <li key={service}>
                    <span className="text-nexora-gray text-sm flex items-center gap-2">
                      <span className="w-1 h-1 rounded-full bg-nexora-cyan/50" />
                      {service}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* ==========================================
                COLUMN 4: Contact Info
                ========================================== */}
            <div>
              <h4 className="font-orbitron text-sm font-semibold text-white mb-6 tracking-wider">
                CONTACTO
              </h4>
              <ul className="space-y-4">
                {/* Email */}
                <li>
                  <a
                    href={`mailto:${contactInfo.email}`}
                    className="flex items-start gap-3 text-nexora-gray hover:text-nexora-cyan transition-colors group"
                  >
                    <Mail className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{contactInfo.email}</span>
                  </a>
                </li>

                {/* Phone */}
                <li>
                  <a
                    href={`tel:${contactInfo.phone.replace(/\s/g, '')}`}
                    className="flex items-start gap-3 text-nexora-gray hover:text-nexora-cyan transition-colors group"
                  >
                    <Phone className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{contactInfo.phone}</span>
                  </a>
                </li>

                {/* Address */}
                <li>
                  <div className="flex items-start gap-3 text-nexora-gray">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{contactInfo.address}</span>
                  </div>
                </li>

                {/* WhatsApp CTA */}
                <li className="pt-2">
                  <a
                    href={contactInfo.whatsapp}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 hover:bg-green-500/20 hover:border-green-500/50 transition-all group"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span className="text-sm font-medium">WhatsApp Directo</span>
                    <ArrowUpRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* ==========================================
              BOTTOM BAR
              ========================================== */}
          <div className="mt-16 pt-8 border-t border-nexora-cyan/10">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Copyright */}
              <p className="text-nexora-gray text-sm text-center md:text-left">
                &copy; {new Date().getFullYear()} Nexora Analytics & AI. Todos los derechos reservados.
              </p>

              {/* Links legales */}
              <div className="flex items-center gap-6">
                <a href="#" className="text-nexora-gray text-sm hover:text-nexora-cyan transition-colors">
                  Política de Privacidad
                </a>
                <a href="#" className="text-nexora-gray text-sm hover:text-nexora-cyan transition-colors">
                  Términos de Servicio
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ==========================================
          DECORATIVE ELEMENTS
          ========================================== */}
      {/* Glow en la esquina */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-nexora-cyan/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 left-0 w-64 h-64 bg-nexora-cyan/3 rounded-full blur-3xl pointer-events-none" />
    </footer>
  );
};

export default Footer;
