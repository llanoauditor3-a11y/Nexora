/**
 * ==========================================
 * SERVICES SECTION COMPONENT
 * ==========================================
 * 
 * Características:
 * - Tres tarjetas con efecto glassmorphism
 * - Iconos brillantes con animaciones
 * - Efecto hover con elevación y glow
 * - Fondo translúcido con blur
 * - Animaciones de entrada al scroll
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useEffect, useRef, useState } from 'react';
import { BarChart3, Brain, TrendingUp, ArrowRight } from 'lucide-react';

// Interface para los servicios
interface Service {
  id: number;
  icon: React.ElementType;
  title: string;
  subtitle: string;
  description: string;
  features: string[];
}

const ServicesSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  // Detectar cuando la sección está visible
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Datos de los servicios
  const services: Service[] = [
    {
      id: 1,
      icon: BarChart3,
      title: 'Análisis de Datos',
      subtitle: 'Dashboards Avanzados',
      description: 'Transformamos datos complejos en visualizaciones intuitivas y accionables para tu negocio.',
      features: [
        'Dashboards en tiempo real',
        'KPIs personalizados',
        'Reportes automatizados',
      ],
    },
    {
      id: 2,
      icon: Brain,
      title: 'Inteligencia Artificial',
      subtitle: 'Machine Learning y IA',
      description: 'Implementamos soluciones de IA que aprenden y se adaptan para optimizar tus procesos.',
      features: [
        'Modelos predictivos',
        'Procesamiento de lenguaje natural',
        'Visión por computadora',
      ],
    },
    {
      id: 3,
      icon: TrendingUp,
      title: 'Consultoría Predictiva',
      subtitle: 'Modelos Predictivos',
      description: 'Anticipa tendencias y toma decisiones informadas con nuestros modelos predictivos avanzados.',
      features: [
        'Forecasting de ventas',
        'Análisis de riesgos',
        'Optimización de recursos',
      ],
    },
  ];

  return (
    <section
      id="servicios"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* ==========================================
          BACKGROUND ELEMENTS
          ========================================== */}
      {/* Gradiente de fondo */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B1120] via-[#0F172A] to-[#0B1120]" />
      
      {/* Círculos decorativos con glow */}
      <div className="absolute top-1/4 -left-32 w-64 h-64 bg-nexora-cyan/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-nexora-cyan/5 rounded-full blur-3xl" />

      {/* ==========================================
          CONTENT
          ========================================== */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        
        {/* ==========================================
            SECTION HEADER
            ========================================== */}
        <div className={`text-center mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="section-title font-orbitron text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-nexora-gray max-w-2xl mx-auto mt-4">
            Soluciones integrales de análisis de datos e inteligencia artificial para impulsar tu negocio
          </p>
        </div>

        {/* ==========================================
            SERVICES CARDS GRID
            ========================================== */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 max-w-7xl mx-auto">
          {services.map((service, index) => (
            <ServiceCard
              key={service.id}
              service={service}
              index={index}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// Componente individual para cada tarjeta de servicio
interface ServiceCardProps {
  service: Service;
  index: number;
  isVisible: boolean;
}

const ServiceCard = ({ service, index, isVisible }: ServiceCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const Icon = service.icon;

  return (
    <div
      className={`group relative transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${index * 150}ms` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Tarjeta principal */}
      <div className="glass-card card-hover rounded-2xl p-6 lg:p-8 h-full flex flex-col">
        
        {/* ==========================================
            ICON CONTAINER
            ========================================== */}
        <div className="relative mb-6">
          {/* Glow detrás del icono */}
          <div 
            className={`absolute inset-0 bg-nexora-cyan/20 rounded-xl blur-xl transition-all duration-500 ${
              isHovered ? 'opacity-100 scale-125' : 'opacity-50 scale-100'
            }`}
          />
          
          {/* Icono */}
          <div className="relative w-14 h-14 lg:w-16 lg:h-16 rounded-xl bg-gradient-to-br from-nexora-cyan/20 to-nexora-cyan/5 border border-nexora-cyan/30 flex items-center justify-center">
            <Icon 
              className={`w-7 h-7 lg:w-8 lg:h-8 text-nexora-cyan transition-all duration-300 ${
                isHovered ? 'scale-110' : 'scale-100'
              }`}
            />
          </div>
        </div>

        {/* ==========================================
            TEXT CONTENT
            ========================================== */}
        <div className="flex-grow">
          {/* Título */}
          <h3 className="font-orbitron text-xl lg:text-2xl font-bold text-white mb-1">
            {service.title}
          </h3>
          
          {/* Subtítulo */}
          <p className="text-nexora-cyan text-sm mb-4">
            {service.subtitle}
          </p>
          
          {/* Descripción */}
          <p className="text-nexora-gray text-sm lg:text-base mb-6 leading-relaxed">
            {service.description}
          </p>

          {/* Features list */}
          <ul className="space-y-2 mb-6">
            {service.features.map((feature, idx) => (
              <li key={idx} className="flex items-center gap-2 text-sm text-nexora-gray-light">
                <span className="w-1.5 h-1.5 rounded-full bg-nexora-cyan" />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        {/* ==========================================
            CTA LINK
            ========================================== */}
        <div className="mt-auto pt-4 border-t border-nexora-cyan/10">
          <button className="flex items-center gap-2 text-nexora-cyan text-sm font-medium group/btn">
            <span className="relative">
              Saber más
              <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-nexora-cyan transition-all duration-300 group-hover/btn:w-full" />
            </span>
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-1" />
          </button>
        </div>
      </div>

      {/* Borde brillante en hover */}
      <div 
        className={`absolute inset-0 rounded-2xl border-2 border-nexora-cyan/0 transition-all duration-500 pointer-events-none ${
          isHovered ? 'border-nexora-cyan/30' : ''
        }`}
      />
    </div>
  );
};

export default ServicesSection;
