/**
 * ==========================================
 * HERO SECTION COMPONENT
 * ==========================================
 * 
 * Características:
 * - Fondo de ciudad digital futurista
 * - Overlay oscuro con gradiente
 * - Título principal con efecto glow
 * - Subtítulo animado
 * - Botón CTA con efecto neón
 * - Partículas animadas de fondo
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useEffect, useRef } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

const HeroSection = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Efecto para crear partículas animadas en el canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Guardar dimensiones del canvas
    let canvasWidth = window.innerWidth;
    let canvasHeight = window.innerHeight;

    // Ajustar tamaño del canvas
    const resizeCanvas = () => {
      canvasWidth = window.innerWidth;
      canvasHeight = window.innerHeight;
      canvas.width = canvasWidth;
      canvas.height = canvasHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Clase para las partículas
    class Particle {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;

      constructor() {
        this.x = Math.random() * canvasWidth;
        this.y = Math.random() * canvasHeight;
        this.size = Math.random() * 2 + 0.5;
        this.speedX = (Math.random() - 0.5) * 0.5;
        this.speedY = (Math.random() - 0.5) * 0.5;
        this.opacity = Math.random() * 0.5 + 0.2;
      }

      update() {
        this.x += this.speedX;
        this.y += this.speedY;

        // Rebote en los bordes
        if (this.x < 0 || this.x > canvasWidth) this.speedX *= -1;
        if (this.y < 0 || this.y > canvasHeight) this.speedY *= -1;
      }

      draw() {
        if (!ctx) return;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 245, 255, ${this.opacity})`;
        ctx.fill();
      }
    }

    // Crear partículas
    const particles: Particle[] = [];
    const particleCount = Math.min(50, Math.floor(window.innerWidth / 30));
    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle());
    }

    // Animación
    let animationId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvasWidth, canvasHeight);

      // Dibujar conexiones entre partículas cercanas
      particles.forEach((particle, i) => {
        particle.update();
        particle.draw();

        // Conectar partículas cercanas
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[j].x - particle.x;
          const dy = particles[j].y - particle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 150) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(0, 245, 255, ${0.1 * (1 - distance / 150)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particle.x, particle.y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  // Función para scroll suave a servicios
  const scrollToServices = () => {
    const element = document.querySelector('#servicios');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* ==========================================
          BACKGROUND IMAGE
          ========================================== */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(/images/hero-bg.jpg)',
        }}
      />

      {/* ==========================================
          CANVAS PARTICLES OVERLAY
          ========================================== */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ zIndex: 1 }}
      />

      {/* ==========================================
          DARK OVERLAY GRADIENT
          ========================================== */}
      <div className="absolute inset-0 hero-overlay" style={{ zIndex: 2 }} />

      {/* ==========================================
          CONTENT
          ========================================== */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20 pt-20">
        <div className="max-w-5xl mx-auto text-center">
          
          {/* Badge superior */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8 animate-fade-in">
            <Sparkles className="w-4 h-4 text-nexora-cyan" />
            <span className="text-sm text-nexora-gray">
              Inteligencia Artificial de Próxima Generación
            </span>
          </div>

          {/* ==========================================
              MAIN TITLE
              ========================================== */}
          <h1 className="font-orbitron text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight animate-slide-up">
            <span className="block">Nexora:</span>
            <span className="block mt-2">
              <span className="text-gradient glow-text">El futuro de tus datos, hoy</span>
            </span>
          </h1>

          {/* ==========================================
              SUBTITLE
              ========================================== */}
          <p className="text-lg sm:text-xl md:text-2xl text-nexora-gray max-w-3xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            Transformamos datos en decisiones inteligentes
          </p>

          {/* ==========================================
              CTA BUTTON
              ========================================== */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <button
              onClick={scrollToServices}
              className="neon-button-primary group px-8 py-4 rounded-xl text-lg font-semibold flex items-center gap-3"
            >
              <span>Descubre Más</span>
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>

          {/* ==========================================
              STATS ROW
              ========================================== */}
          <div className="grid grid-cols-3 gap-4 sm:gap-8 mt-16 max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.6s' }}>
            {[
              { value: '500+', label: 'Proyectos' },
              { value: '98%', label: 'Satisfacción' },
              { value: '24/7', label: 'Soporte IA' },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="font-orbitron text-2xl sm:text-3xl md:text-4xl font-bold text-nexora-cyan glow-text">
                  {stat.value}
                </div>
                <div className="text-xs sm:text-sm text-nexora-gray mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ==========================================
          BOTTOM GRADIENT FADE
          ========================================== */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0B1120] to-transparent"
        style={{ zIndex: 3 }}
      />

      {/* ==========================================
          DECORATIVE ELEMENTS
          ========================================== */}
      {/* Líneas decorativas en las esquinas */}
      <div className="absolute top-20 left-8 w-20 h-20 border-l-2 border-t-2 border-nexora-cyan/20 rounded-tl-3xl hidden lg:block" />
      <div className="absolute top-20 right-8 w-20 h-20 border-r-2 border-t-2 border-nexora-cyan/20 rounded-tr-3xl hidden lg:block" />
    </section>
  );
};

export default HeroSection;
