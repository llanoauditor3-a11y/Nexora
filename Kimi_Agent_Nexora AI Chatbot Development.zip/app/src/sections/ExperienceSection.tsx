/**
 * ==========================================
 * EXPERIENCE SECTION COMPONENT
 * ==========================================
 * 
 * Características:
 * - Imagen lateral de científico de datos
 * - Interfaz holográfica simulada
 * - Descripción de chatbot IA
 * - Ventana de chat flotante moderna
 * - Animaciones de entrada
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import { useEffect, useRef, useState } from 'react';
import { Bot, User, Send, X, Minimize2, Maximize2 } from 'lucide-react';

// Interface para mensajes del chat
interface ChatMessage {
  id: number;
  type: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

const ExperienceSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  
  // Estados del chatbot
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      type: 'bot',
      text: '¡Hola! ¿Cómo puedo ayudarte hoy?',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Detectar cuando la sección está visible
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Auto-scroll al último mensaje
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Función para enviar mensaje
  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Agregar mensaje del usuario
    const userMessage: ChatMessage = {
      id: messages.length + 1,
      type: 'user',
      text: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simular respuesta del bot
    setTimeout(() => {
      const botResponses: Record<string, string> = {
        'analisis': '¡Claro! Te proporcionaré toda la información que necesites sobre nuestros servicios de análisis de datos. ¿Te gustaría agendar una demostración?',
        'datos': 'Nuestros servicios de análisis de datos incluyen dashboards en tiempo real, KPIs personalizados y reportes automatizados.',
        'ia': 'Implementamos soluciones de IA de última generación incluyendo modelos predictivos, NLP y visión por computadora.',
        'precio': 'Nuestros planes son flexibles según tus necesidades. ¿Te gustaría una consulta gratuita para evaluar tu proyecto?',
        'contacto': 'Puedes contactarnos por WhatsApp o email. Nuestro equipo está disponible 24/7 para atenderte.',
      };

      const lowerInput = inputValue.toLowerCase();
      let botResponse = '¡Interesante! Cuéntame más sobre lo que necesitas y te ayudaré con la información adecuada.';

      for (const [key, response] of Object.entries(botResponses)) {
        if (lowerInput.includes(key)) {
          botResponse = response;
          break;
        }
      }

      const botMessage: ChatMessage = {
        id: messages.length + 2,
        type: 'bot',
        text: botResponse,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  // Manejar tecla Enter
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <section
      id="experiencia"
      ref={sectionRef}
      className="relative py-20 lg:py-32 overflow-hidden"
    >
      {/* ==========================================
          BACKGROUND ELEMENTS
          ========================================== */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B1120] via-[#0F172A] to-[#0B1120]" />
      
      {/* Líneas decorativas */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-nexora-cyan/30 to-transparent" />

      {/* ==========================================
          CONTENT
          ========================================== */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        
        {/* ==========================================
            SECTION HEADER
            ========================================== */}
        <div className={`text-center mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="section-title font-orbitron text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Experiencia Inteligente 24/7
          </h2>
        </div>

        {/* ==========================================
            MAIN CONTENT GRID
            ========================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 max-w-7xl mx-auto items-center">
          
          {/* ==========================================
              LEFT COLUMN - Image & Description
              ========================================== */}
          <div className={`transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'}`}>
            {/* Imagen con efecto holográfico */}
            <div className="relative mb-8">
              {/* Glow detrás de la imagen */}
              <div className="absolute inset-0 bg-nexora-cyan/10 rounded-2xl blur-2xl" />
              
              {/* Marco decorativo */}
              <div className="absolute -inset-2 border border-nexora-cyan/20 rounded-2xl" />
              <div className="absolute -inset-4 border border-nexora-cyan/10 rounded-2xl" />
              
              {/* Imagen */}
              <div className="relative rounded-xl overflow-hidden">
                <img
                  src="/images/data-scientist.jpg"
                  alt="Científico de datos trabajando con interfaz holográfica"
                  className="w-full h-auto object-cover"
                />
                
                {/* Overlay holográfico */}
                <div className="absolute inset-0 bg-gradient-to-t from-nexora-midnight/80 via-transparent to-transparent" />
                
                {/* Escaner line animation */}
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                  <div 
                    className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-nexora-cyan to-transparent animate-[scan_3s_ease-in-out_infinite]"
                    style={{
                      animation: 'scan 3s ease-in-out infinite',
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Descripción */}
            <div className="space-y-4">
              <h3 className="font-orbitron text-xl lg:text-2xl font-bold text-white">
                Soporte 24/7 con nuestro{' '}
                <span className="text-nexora-cyan">Chatbot IA</span>
              </h3>
              <p className="text-nexora-gray leading-relaxed">
                Asistencia instantánea, siempre disponible para ti. Nuestro chatbot inteligente 
                está entrenado para responder tus preguntas sobre servicios, precios y ayudarte 
                a encontrar la solución perfecta para tu negocio.
              </p>
              
              {/* Features */}
              <div className="flex flex-wrap gap-3 pt-2">
                {['Respuesta inmediata', 'Disponible 24/7', 'Multilenguaje'].map((feature, idx) => (
                  <span 
                    key={idx}
                    className="px-3 py-1 text-xs text-nexora-cyan border border-nexora-cyan/30 rounded-full bg-nexora-cyan/5"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* ==========================================
              RIGHT COLUMN - Chat Interface
              ========================================== */}
          <div className={`transition-all duration-700 delay-400 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'}`}>
            {/* Ventana de chat */}
            <div className="glass-card rounded-2xl overflow-hidden shadow-2xl shadow-black/40">
              
              {/* Header del chat */}
              <div className="flex items-center justify-between px-4 py-3 border-b border-nexora-cyan/10 bg-nexora-dark-blue/50">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="absolute inset-0 bg-nexora-cyan/30 rounded-full blur-md animate-pulse" />
                    <Bot className="w-6 h-6 text-nexora-cyan relative z-10" />
                  </div>
                  <div>
                    <span className="text-sm font-medium text-white">Chat</span>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-xs text-nexora-gray">En línea</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setIsChatOpen(!isChatOpen)}
                    className="p-1.5 text-nexora-gray hover:text-nexora-cyan transition-colors"
                  >
                    {isChatOpen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </button>
                  <button className="p-1.5 text-nexora-gray hover:text-nexora-cyan transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Área de mensajes */}
              {isChatOpen && (
                <>
                  <div className="h-80 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-nexora-midnight/50 to-nexora-dark-blue/30">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}
                      >
                        {/* Avatar */}
                        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                          message.type === 'user' 
                            ? 'bg-nexora-cyan/20' 
                            : 'bg-nexora-dark-blue border border-nexora-cyan/30'
                        }`}>
                          {message.type === 'user' ? (
                            <User className="w-4 h-4 text-nexora-cyan" />
                          ) : (
                            <Bot className="w-4 h-4 text-nexora-cyan" />
                          )}
                        </div>
                        
                        {/* Mensaje */}
                        <div className={`max-w-[75%] px-4 py-2.5 text-sm ${
                          message.type === 'user'
                            ? 'chat-bubble-user text-white'
                            : 'chat-bubble-bot text-nexora-gray-light'
                        }`}>
                          {message.text}
                        </div>
                      </div>
                    ))}
                    
                    {/* Indicador de escritura */}
                    {isTyping && (
                      <div className="flex gap-3">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-nexora-dark-blue border border-nexora-cyan/30 flex items-center justify-center">
                          <Bot className="w-4 h-4 text-nexora-cyan" />
                        </div>
                        <div className="chat-bubble-bot px-4 py-3 flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-nexora-cyan/50 animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-2 h-2 rounded-full bg-nexora-cyan/50 animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-2 h-2 rounded-full bg-nexora-cyan/50 animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    )}
                    
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Input area */}
                  <div className="p-3 border-t border-nexora-cyan/10 bg-nexora-dark-blue/50">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Escribe tu mensaje..."
                        className="flex-1 px-4 py-2.5 text-sm text-white bg-nexora-midnight/80 border border-nexora-cyan/20 rounded-xl focus:outline-none focus:border-nexora-cyan/50 focus:ring-1 focus:ring-nexora-cyan/30 placeholder:text-nexora-gray/50"
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={!inputValue.trim()}
                        className="px-4 py-2.5 bg-nexora-cyan text-nexora-midnight rounded-xl hover:bg-nexora-cyan-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Sugerencias de mensajes */}
            <div className="flex flex-wrap gap-2 mt-4 justify-center">
              {['¿Quiero información sobre análisis de datos?', '¿Cuáles son los precios?', '¿Cómo funciona la IA?'].map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setInputValue(suggestion);
                  }}
                  className="px-3 py-1.5 text-xs text-nexora-gray border border-nexora-cyan/20 rounded-full hover:border-nexora-cyan/50 hover:text-nexora-cyan transition-all"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Animación CSS para el escáner */}
      <style>{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </section>
  );
};

export default ExperienceSection;
