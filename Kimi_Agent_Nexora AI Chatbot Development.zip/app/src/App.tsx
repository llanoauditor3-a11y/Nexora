/**
 * ==========================================
 * NEXORA ANALYTICS & AI - MAIN APP
 * ==========================================
 * 
 * Aplicación principal que integra todas las secciones
 * de la landing page futurista.
 * 
 * Estructura:
 * 1. Header (Navegación fija)
 * 2. HeroSection (Sección principal)
 * 3. ServicesSection (Tarjetas de servicios)
 * 4. ExperienceSection (Chatbot 24/7)
 * 5. GallerySection (Galería visual)
 * 6. Footer (Pie de página)
 * 7. ChatbotWidget (Botón flotante)
 * 
 * @author Nexora Analytics & AI
 * @version 1.0.0
 */

import Header from './sections/Header';
import HeroSection from './sections/HeroSection';
import ServicesSection from './sections/ServicesSection';
import ExperienceSection from './sections/ExperienceSection';
import GallerySection from './sections/GallerySection';
import FAQSection from './sections/FAQSection';
import Footer from './sections/Footer';
import ChatbotWidget from './components/ChatbotWidget';

function App() {
  return (
    <div className="min-h-screen bg-[#0B1120] text-white overflow-x-hidden">
      {/* ==========================================
          FIXED HEADER
          ========================================== */}
      <Header />

      {/* ==========================================
          MAIN CONTENT
          ========================================== */}
      <main>
        {/* Hero Section - Fondo futurista con ciudad digital */}
        <HeroSection />

        {/* Services Section - Tarjetas glassmorphism */}
        <ServicesSection />

        {/* Experience Section - Chatbot IA 24/7 */}
        <ExperienceSection />

        {/* Gallery Section - Imágenes tecnológicas */}
        <GallerySection />

        {/* FAQ Section - Preguntas Frecuentes */}
        <FAQSection />
      </main>

      {/* ==========================================
          FOOTER
          ========================================== */}
      <Footer />

      {/* ==========================================
          FLOATING CHATBOT WIDGET
          ========================================== */}
      <ChatbotWidget />
    </div>
  );
}

export default App;
